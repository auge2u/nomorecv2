import { Trait } from '../interfaces/models';
import supabase from '../core/supabase';
import logger from '../utils/logger';
import { AppError } from '../middleware/error.middleware';
import config from '../config';

/**
 * Service for managing persona traits
 */
export class TraitService {
  /**
   * Get a trait by ID
   */
  async getTraitById(traitId: string): Promise<Trait> {
    try {
      const { data, error } = await supabase
        .from('traits')
        .select('*')
        .eq('id', traitId)
        .single();

      if (error) {
        logger.error('Error fetching trait', { error, traitId });
        throw new AppError(`Trait not found: ${error.message}`, 404);
      }

      return data as Trait;
    } catch (error) {
      logger.error('Error in getTraitById', { error, traitId });
      throw error instanceof AppError ? error : new AppError('Failed to fetch trait', 500);
    }
  }

  /**
   * Get traits for a profile
   */
  async getTraitsForProfile(profileId: string, category?: string): Promise<Trait[]> {
    try {
      let query = supabase
        .from('traits')
        .select('*')
        .eq('profileId', profileId)
        .order('score', { ascending: false });

      if (category) {
        query = query.eq('category', category);
      }

      const { data, error } = await query;

      if (error) {
        logger.error('Error fetching traits for profile', { error, profileId, category });
        throw new AppError(`Failed to fetch traits: ${error.message}`, 400);
      }

      return data as Trait[];
    } catch (error) {
      logger.error('Error in getTraitsForProfile', { error, profileId, category });
      throw error instanceof AppError ? error : new AppError('Failed to fetch traits', 500);
    }
  }

  /**
   * Create a new trait
   */
  async createTrait(trait: Omit<Trait, 'id' | 'createdAt' | 'updatedAt'>): Promise<Trait> {
    try {
      const { data, error } = await supabase
        .from('traits')
        .insert([{
          ...trait,
          assessmentDate: trait.assessmentDate || new Date(),
          createdAt: new Date(),
          updatedAt: new Date()
        }])
        .select()
        .single();

      if (error) {
        logger.error('Error creating trait', { error, trait });
        throw new AppError(`Failed to create trait: ${error.message}`, 400);
      }

      return data as Trait;
    } catch (error) {
      logger.error('Error in createTrait', { error, trait });
      throw error instanceof AppError ? error : new AppError('Failed to create trait', 500);
    }
  }

  /**
   * Update an existing trait
   */
  async updateTrait(traitId: string, updates: Partial<Trait>): Promise<Trait> {
    try {
      const { data, error } = await supabase
        .from('traits')
        .update({
          ...updates,
          updatedAt: new Date(),
          ...(updates.score !== undefined ? { assessmentDate: new Date() } : {})
        })
        .eq('id', traitId)
        .select()
        .single();

      if (error) {
        logger.error('Error updating trait', { error, traitId, updates });
        throw new AppError(`Failed to update trait: ${error.message}`, 400);
      }

      return data as Trait;
    } catch (error) {
      logger.error('Error in updateTrait', { error, traitId, updates });
      throw error instanceof AppError ? error : new AppError('Failed to update trait', 500);
    }
  }

  /**
   * Delete a trait
   */
  async deleteTrait(traitId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('traits')
        .delete()
        .eq('id', traitId);

      if (error) {
        logger.error('Error deleting trait', { error, traitId });
        throw new AppError(`Failed to delete trait: ${error.message}`, 400);
      }
    } catch (error) {
      logger.error('Error in deleteTrait', { error, traitId });
      throw error instanceof AppError ? error : new AppError('Failed to delete trait', 500);
    }
  }

  /**
   * Assess traits based on profile data
   * This method analyzes profile data to derive trait scores
   */
  async assessTraitsFromProfile(profileId: string): Promise<Trait[]> {
    try {
      logger.info('Assessing traits from profile data', { profileId });
      
      // Fetch profile data including experiences, skills, projects, etc.
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', profileId)
        .single();
        
      if (profileError) {
        throw new AppError(`Profile not found: ${profileError.message}`, 404);
      }
      
      // Fetch related data
      const [experiencesResult, skillsResult, projectsResult, educationResult] = await Promise.all([
        supabase.from('experiences').select('*').eq('profileId', profileId),
        supabase.from('skills').select('*').eq('profileId', profileId),
        supabase.from('projects').select('*').eq('profileId', profileId),
        supabase.from('education').select('*').eq('profileId', profileId)
      ]);
      
      const experiences = experiencesResult.data || [];
      const skills = skillsResult.data || [];
      const projects = projectsResult.data || [];
      const education = educationResult.data || [];
      
      // Define trait categories and assessment rules
      const traitAssessments = [
        {
          name: 'Leadership',
          category: 'professional',
          assessmentMethod: 'derived' as const,
          score: this.calculateLeadershipScore(experiences, skills, projects)
        },
        {
          name: 'Technical Expertise',
          category: 'professional',
          assessmentMethod: 'derived' as const,
          score: this.calculateTechnicalScore(skills, projects, experiences)
        },
        {
          name: 'Innovation',
          category: 'professional',
          assessmentMethod: 'derived' as const,
          score: this.calculateInnovationScore(projects, experiences)
        },
        {
          name: 'Communication',
          category: 'professional',
          assessmentMethod: 'derived' as const,
          score: this.calculateCommunicationScore(experiences, projects, profile)
        },
        {
          name: 'Problem Solving',
          category: 'professional',
          assessmentMethod: 'derived' as const,
          score: this.calculateProblemSolvingScore(experiences, projects)
        },
        {
          name: 'Adaptability',
          category: 'personal',
          assessmentMethod: 'derived' as const,
          score: this.calculateAdaptabilityScore(experiences, skills, education)
        },
        {
          name: 'Strategic Thinking',
          category: 'professional',
          assessmentMethod: 'derived' as const,
          score: this.calculateStrategicThinkingScore(experiences, projects)
        }
      ];
      
      // Create or update traits
      const traits: Trait[] = [];
      
      for (const assessment of traitAssessments) {
        // Check if trait already exists
        const { data: existingTraits, error: traitsError } = await supabase
          .from('traits')
          .select('*')
          .eq('profileId', profileId)
          .eq('name', assessment.name)
          .eq('assessmentMethod', 'derived');
          
        if (traitsError) {
          logger.error('Error checking existing traits', { error: traitsError, profileId, traitName: assessment.name });
          continue;
        }
        
        let trait: Trait;
        
        if (existingTraits && existingTraits.length > 0) {
          // Update existing trait
          trait = await this.updateTrait(existingTraits[0].id, {
            score: assessment.score,
            assessmentDate: new Date()
          });
        } else {
          // Create new trait
          trait = await this.createTrait({
            profileId,
            name: assessment.name,
            category: assessment.category,
            score: assessment.score,
            assessmentMethod: assessment.assessmentMethod,
            assessmentDate: new Date()
          });
        }
        
        traits.push(trait);
      }
      
      return traits;
    } catch (error) {
      logger.error('Error in assessTraitsFromProfile', { error, profileId });
      throw error instanceof AppError ? error : new AppError('Failed to assess traits', 500);
    }
  }

  /**
   * Get trait recommendations based on industry
   * This method provides recommendations for improving traits based on industry standards
   */
  async getTraitRecommendations(profileId: string, industry: string): Promise<any> {
    try {
      logger.info('Getting trait recommendations', { profileId, industry });
      
      // Get current traits
      const traits = await this.getTraitsForProfile(profileId);
      
      // Define industry benchmarks
      const industryBenchmarks: Record<string, Record<string, number>> = {
        'technology': {
          'Technical Expertise': 85,
          'Innovation': 80,
          'Problem Solving': 85,
          'Adaptability': 80,
          'Communication': 75,
          'Leadership': 70,
          'Strategic Thinking': 75
        },
        'finance': {
          'Technical Expertise': 75,
          'Innovation': 65,
          'Problem Solving': 80,
          'Adaptability': 70,
          'Communication': 80,
          'Leadership': 75,
          'Strategic Thinking': 85
        },
        'healthcare': {
          'Technical Expertise': 70,
          'Innovation': 70,
          'Problem Solving': 80,
          'Adaptability': 75,
          'Communication': 85,
          'Leadership': 75,
          'Strategic Thinking': 70
        },
        'retail': {
          'Technical Expertise': 65,
          'Innovation': 75,
          'Problem Solving': 75,
          'Adaptability': 85,
          'Communication': 85,
          'Leadership': 80,
          'Strategic Thinking': 75
        },
        'consulting': {
          'Technical Expertise': 75,
          'Innovation': 80,
          'Problem Solving': 85,
          'Adaptability': 85,
          'Communication': 90,
          'Leadership': 85,
          'Strategic Thinking': 90
        }
      };
      
      // Use default benchmarks if industry not found
      const benchmarks = industryBenchmarks[industry.toLowerCase()] || industryBenchmarks['technology'];
      
      // Generate recommendations
      const recommendations = traits.map(trait => {
        const benchmark = benchmarks[trait.name] || 75; // Default benchmark if not specified
        const gap = benchmark - trait.score;
        
        return {
          trait: trait.name,
          currentScore: trait.score,
          industryBenchmark: benchmark,
          gap: gap,
          needsImprovement: gap > 5,
          recommendations: this.getRecommendationsForTrait(trait.name, gap)
        };
      });
      
      // Sort by gap (largest first)
      recommendations.sort((a, b) => b.gap - a.gap);
      
      return {
        industry,
        overallAssessment: this.getOverallAssessment(recommendations),
        recommendations
      };
    } catch (error) {
      logger.error('Error in getTraitRecommendations', { error, profileId, industry });
      throw error instanceof AppError ? error : new AppError('Failed to get trait recommendations', 500);
    }
  }

  /**
   * Calculate leadership score based on profile data
   */
  private calculateLeadershipScore(experiences: any[], skills: any[], projects: any[]): number {
    // Leadership indicators in experiences
    const leadershipTitles = ['manager', 'director', 'lead', 'chief', 'head', 'vp', 'president', 'founder'];
    const leadershipKeywords = ['team', 'manage', 'direct', 'lead', 'oversee', 'supervise', 'coordinate'];
    
    // Count leadership indicators
    let leadershipPoints = 0;
    
    // Check experience titles and descriptions
    for (const exp of experiences) {
      const title = exp.title.toLowerCase();
      const description = exp.description.toLowerCase();
      
      // Check for leadership titles
      if (leadershipTitles.some(lt => title.includes(lt))) {
        leadershipPoints += 10;
      }
      
      // Check for leadership keywords in description
      const keywordsFound = leadershipKeywords.filter(kw => description.includes(kw)).length;
      leadershipPoints += keywordsFound * 2;
      
      // Points for team size if available
      if (exp.achievements) {
        const teamSizeMatch = exp.achievements.join(' ').match(/team of (\d+)/i);
        if (teamSizeMatch && teamSizeMatch[1]) {
          const teamSize = parseInt(teamSizeMatch[1]);
          leadershipPoints += Math.min(teamSize / 2, 10); // Cap at 10 points
        }
      }
    }
    
    // Check for leadership skills
    const leadershipSkills = ['leadership', 'management', 'team building', 'mentoring', 'coaching'];
    for (const skill of skills) {
      if (leadershipSkills.some(ls => skill.name.toLowerCase().includes(ls))) {
        leadershipPoints += 5;
      }
    }
    
    // Check for leadership in projects
    for (const project of projects) {
      const description = project.description.toLowerCase();
      if (leadershipKeywords.some(kw => description.includes(kw))) {
        leadershipPoints += 3;
      }
    }
    
    // Normalize to 0-100 scale
    return Math.min(Math.round(leadershipPoints * 1.5), 100);
  }

  /**
   * Calculate technical expertise score based on profile data
   */
  private calculateTechnicalScore(skills: any[], projects: any[], experiences: any[]): number {
    let technicalPoints = 0;
    
    // Points for number of skills
    technicalPoints += Math.min(skills.length * 2, 30);
    
    // Points for skill levels
    for (const skill of skills) {
      technicalPoints += skill.level || 0;
    }
    
    // Points for technical projects
    for (const project of projects) {
      if (project.skills && project.skills.length > 0) {
        technicalPoints += Math.min(project.skills.length, 5);
      }
    }
    
    // Points for technical experience
    const technicalTitles = ['engineer', 'developer', 'architect', 'technical', 'technology'];
    for (const exp of experiences) {
      const title = exp.title.toLowerCase();
      if (technicalTitles.some(tt => title.includes(tt))) {
        technicalPoints += 5;
      }
    }
    
    // Normalize to 0-100 scale
    return Math.min(Math.round(technicalPoints * 1.2), 100);
  }

  /**
   * Calculate innovation score based on profile data
   */
  private calculateInnovationScore(projects: any[], experiences: any[]): number {
    let innovationPoints = 0;
    
    // Innovation keywords
    const innovationKeywords = ['innovat', 'creat', 'novel', 'new', 'first', 'pioneer', 'transform', 'disrupt', 'revolution'];
    
    // Check projects for innovation indicators
    for (const project of projects) {
      const description = project.description.toLowerCase();
      const keywordsFound = innovationKeywords.filter(kw => description.includes(kw)).length;
      innovationPoints += keywordsFound * 3;
      
      // Points for outcomes
      if (project.outcomes) {
        for (const outcome of project.outcomes) {
          const outcomeText = outcome.toLowerCase();
          if (innovationKeywords.some(kw => outcomeText.includes(kw))) {
            innovationPoints += 2;
          }
        }
      }
    }
    
    // Check experiences for innovation indicators
    for (const exp of experiences) {
      const description = exp.description.toLowerCase();
      const keywordsFound = innovationKeywords.filter(kw => description.includes(kw)).length;
      innovationPoints += keywordsFound * 2;
      
      // Points for achievements
      if (exp.achievements) {
        for (const achievement of exp.achievements) {
          const achievementText = achievement.toLowerCase();
          if (innovationKeywords.some(kw => achievementText.includes(kw))) {
            innovationPoints += 3;
          }
        }
      }
    }
    
    // Normalize to 0-100 scale
    return Math.min(Math.round(innovationPoints * 1.5), 100);
  }

  /**
   * Calculate communication score based on profile data
   */
  private calculateCommunicationScore(experiences: any[], projects: any[], profile: any): number {
    let communicationPoints = 0;
    
    // Communication keywords
    const communicationKeywords = ['communicat', 'present', 'speak', 'write', 'author', 'publish', 'document', 'articulate'];
    
    // Check profile summary
    if (profile.summary) {
      const summary = profile.summary.toLowerCase();
      const keywordsFound = communicationKeywords.filter(kw => summary.includes(kw)).length;
      communicationPoints += keywordsFound * 2;
      
      // Quality of writing in summary (length as a proxy)
      communicationPoints += Math.min(Math.floor(profile.summary.length / 100), 10);
    }
    
    // Check experiences for communication indicators
    for (const exp of experiences) {
      const description = exp.description.toLowerCase();
      const keywordsFound = communicationKeywords.filter(kw => description.includes(kw)).length;
      communicationPoints += keywordsFound * 2;
      
      // Check for communication-related achievements
      if (exp.achievements) {
        for (const achievement of exp.achievements) {
          const achievementText = achievement.toLowerCase();
          if (communicationKeywords.some(kw => achievementText.includes(kw))) {
            communicationPoints += 3;
          }
        }
      }
    }
    
    // Check projects for communication indicators
    for (const project of projects) {
      const description = project.description.toLowerCase();
      const keywordsFound = communicationKeywords.filter(kw => description.includes(kw)).length;
      communicationPoints += keywordsFound * 1;
    }
    
    // Normalize to 0-100 scale
    return Math.min(Math.round(communicationPoints * 1.8), 100);
  }

  /**
   * Calculate problem solving score based on profile data
   */
  private calculateProblemSolvingScore(experiences: any[], projects: any[]): number {
    let problemSolvingPoints = 0;
    
    // Problem solving keywords
    const problemSolvingKeywords = ['solv', 'problem', 'challenge', 'obstacle', 'issue', 'improve', 'optimize', 'solution', 'resolve'];
    
    // Check experiences for problem solving indicators
    for (const exp of experiences) {
      const description = exp.description.toLowerCase();
      const keywordsFound = problemSolvingKeywords.filter(kw => description.includes(kw)).length;
      problemSolvingPoints += keywordsFound * 2;
      
      // Check for problem solving achievements
      if (exp.achievements) {
        for (const achievement of exp.achievements) {
          const achievementText = achievement.toLowerCase();
          if (problemSolvingKeywords.some(kw => achievementText.includes(kw))) {
            problemSolvingPoints += 3;
          }
          
          // Points for quantifiable improvements
          if (/increased|improved|reduced|decreased|by \d+%/i.test(achievementText)) {
            problemSolvingPoints += 5;
          }
        }
      }
    }
    
    // Check projects for problem solving indicators
    for (const project of projects) {
      const description = project.description.toLowerCase();
      const keywordsFound = problemSolvingKeywords.filter(kw => description.includes(kw)).length;
      problemSolvingPoints += keywordsFound * 2;
      
      // Check for problem solving outcomes
      if (project.outcomes) {
        for (const outcome of project.outcomes) {
          const outcomeText = outcome.toLowerCase();
          if (problemSolvingKeywords.some(kw => outcomeText.includes(kw))) {
            problemSolvingPoints += 3;
          }
        }
      }
    }
    
    // Normalize to 0-100 scale
    return Math.min(Math.round(problemSolvingPoints * 1.5), 100);
  }

  /**
   * Calculate adaptability score based on profile data
   */
  private calculateAdaptabilityScore(experiences: any[], skills: any[], education: any[]): number {
    let adaptabilityPoints = 0;
    
    // Adaptability keywords
    const adaptabilityKeywords = ['adapt', 'flexible', 'versatile', 'agile', 'change', 'evolv', 'learn', 'adjust', 'pivot'];
    
    // Points for diverse experiences (different companies/roles)
    const companies = new Set(experiences.map((exp: any) => exp.company));
    adaptabilityPoints += Math.min(companies.size * 5, 25);
    
    // Points for diverse skills across categories
    const skillCategories = new Set(skills.map((skill: any) => skill.category));
    adaptabilityPoints += Math.min(skillCategories.size * 5, 20);
    
    // Check experiences for adaptability indicators
    for (const exp of experiences) {
      const description = exp.description.toLowerCase();
      const keywordsFound = adaptabilityKeywords.filter(kw => description.includes(kw)).length;
      adaptabilityPoints += keywordsFound * 2;
    }
    
    // Points for continuing education
    adaptabilityPoints += Math.min(education.length * 5, 15);
    
    // Points for recent education (last 5 years)
    const recentEducation = education.filter((edu: any) => {
      const endDate = edu.endDate ? new Date(edu.endDate) : new Date();
      const fiveYearsAgo = new Date();
      fiveYearsAgo.setFullYear(fiveYearsAgo.getFullYear() - 5);
      return endDate >= fiveYearsAgo;
    });
    adaptabilityPoints += recentEducation.length * 5;
    
    // Normalize to 0-100 scale
    return Math.min(Math.round(adaptabilityPoints * 1.2), 100);
  }

  /**
   * Calculate strategic thinking score based on profile data
   */
  private calculateStrategicThinkingScore(experiences: any[], projects: any[]): number {
    let strategicPoints = 0;
    
    // Strategic thinking keywords
    const strategicKeywords = ['strateg', 'vision', 'mission', 'goal', 'plan', 'roadmap', 'future', 'direction', 'objective', 'initiative'];
    
    // Check experiences for strategic indicators
    for (const exp of experiences) {
      const description = exp.description.toLowerCase();
      const keywordsFound = strategicKeywords.filter(kw => description.includes(kw)).length;
      strategicPoints += keywordsFound * 2;
      
      // Check for strategic achievements
      if (exp.achievements) {
        for (const achievement of exp.achievements) {
          const achievementText = achievement.toLowerCase();
          if (strategicKeywords.some(kw => achievementText.includes(kw))) {
            strategicPoints += 3;
          }
        }
      }
      
      // Points for strategic titles
      const title = exp.title.toLowerCase();
      if (/strateg|director|vp|chief|head/i.test(title)) {
        strategicPoints += 10;
      }
    }
    
    // Check projects for strategic indicators
    for (const project of projects) {
      const description = project.description.toLowerCase();
      const keywordsFound = strategicKeywords.filter(kw => description.includes(kw)).length;
      strategicPoints += keywordsFound * 2;
      
      // Check for strategic outcomes
      if (project.outcomes) {
        for (const outcome of project.outcomes) {
          const outcomeText = outcome.toLowerCase();
          if (strategicKeywords.some(kw => outcomeText.includes(kw))) {
            strategicPoints += 3;
          }
        }
      }
    }
    
    // Normalize to 0-100 scale
    return Math.min(Math.round(strategicPoints * 1.5), 100);
  }

  /**
   * Get recommendations for improving a specific trait
   */
  private getRecommendationsForTrait(traitName: string, gap: number): string[] {
    // Return empty array if no improvement needed
    if (gap <= 5) {
      return [];
    }
    
    // Trait-specific recommendations
    const recommendations: Record<string, string[]> = {
      'Leadership': [
        'Highlight team management experiences more prominently in your profile',
        'Quantify the size of teams you\'ve led and their achievements',
        'Add specific examples of leadership challenges you\'ve overcome',
        'Include mentoring and coaching experiences in your profile',
        'Showcase strategic initiatives you\'ve led from conception to implementation'
      ],
      'Technical Expertise': [
        'Add more specific technical skills to your profile with proficiency levels',
        'Highlight technical certifications and training',
        'Include more technical details in project descriptions',
        'Showcase complex technical problems you\'ve solved',
        'Demonstrate breadth and depth of technical knowledge across different domains'
      ],
      'Innovation': [
        'Highlight innovative solutions you\'ve developed',
        'Include examples of creative problem-solving',
        'Showcase projects where you introduced new approaches or technologies',
        'Quantify the impact of your innovative solutions',
        'Demonstrate how you\'ve challenged conventional thinking'
      ],
      'Communication': [
        'Include examples of presentations, publications, or documentation you\'ve created',
        'Highlight experience communicating complex ideas to different audiences',
        'Showcase instances where your communication skills led to positive outcomes',
        'Include experience with different communication channels and formats',
        'Demonstrate how you\'ve facilitated understanding across diverse groups'
      ],
      'Problem Solving': [
        'Include more specific examples of complex problems you\'ve solved',
        'Quantify the impact of your solutions',
        'Highlight your analytical approach to problem identification',
        'Showcase your methodology for developing and implementing solutions',
        'Include examples of how you\'ve anticipated and prevented potential issues'
      ],
      'Adaptability': [
        'Highlight experiences working in diverse environments or industries',
        'Showcase how you\'ve successfully navigated change',
        'Include examples of learning new skills or technologies quickly',
        'Demonstrate flexibility in approach when facing obstacles',
        'Include experiences where you\'ve had to pivot strategies'
      ],
      'Strategic Thinking': [
        'Highlight your involvement in strategic planning processes',
        'Include examples of long-term initiatives you\'ve developed',
        'Showcase how you connect tactical actions to strategic objectives',
        'Demonstrate foresight in anticipating market or industry changes',
        'Include examples of how you\'ve aligned team efforts with organizational goals'
      ]
    };
    
    // Return recommendations for the trait, or generic recommendations if not found
    return recommendations[traitName] || [
      'Add more specific examples demonstrating this trait in your profile',
      'Quantify the impact of your work related to this trait',
      'Include more detailed descriptions of your capabilities in this area'
    ];
  }

  /**
   * Get overall assessment based on recommendations
   */
  private getOverallAssessment(recommendations: any[]): string {
    // Count traits needing improvement
    const traitsNeedingImprovement = recommendations.filter(r => r.needsImprovement).length;
    
    // Calculate average gap
    const totalGap = recommendations.reduce((sum, r) => sum + r.gap, 0);
    const averageGap = totalGap / recommendations.length;
    
    // Generate assessment based on gaps
    if (traitsNeedingImprovement === 0) {
      return "Your profile demonstrates strong alignment with industry expectations across all key traits. Continue to maintain and showcase these strengths.";
    } else if (traitsNeedingImprovement <= 2 && averageGap < 10) {
      return `Your profile is well-aligned with industry expectations in most areas, with minor opportunities for improvement in ${recommendations[0].trait} and ${recommendations[1]?.trait || 'other areas'}.`;
    } else if (traitsNeedingImprovement <= 3 && averageGap < 15) {
      return `Your profile shows good potential with several strengths, but could benefit from focused development in ${recommendations[0].trait}, ${recommendations[1]?.trait || 'and'} ${recommendations[2]?.trait || 'other areas'}.`;
    } else {
      return `Your profile would benefit from significant development in several key areas, particularly ${recommendations[0].trait}, ${recommendations[1]?.trait || 'and'} ${recommendations[2]?.trait || 'other traits'} to better align with industry expectations.`;
    }
  }
}

export default new TraitService();
