import { Output } from '../interfaces/models';
import supabase from '../core/supabase';
import logger from '../utils/logger';
import { AppError } from '../middleware/error.middleware';
import profileService from './profile.service';
import traitService from './trait.service';

/**
 * Service for managing output formats and presentations
 */
export class OutputService {
  /**
   * Get an output by ID
   */
  async getOutputById(outputId: string): Promise<Output> {
    try {
      const { data, error } = await supabase
        .from('outputs')
        .select('*')
        .eq('id', outputId)
        .single();

      if (error) {
        logger.error('Error fetching output', { error, outputId });
        throw new AppError(`Output not found: ${error.message}`, 404);
      }

      return data as Output;
    } catch (error) {
      logger.error('Error in getOutputById', { error, outputId });
      throw error instanceof AppError ? error : new AppError('Failed to fetch output', 500);
    }
  }

  /**
   * Get outputs for a profile
   */
  async getOutputsForProfile(profileId: string, options: { outputType?: string; format?: string } = {}): Promise<Output[]> {
    try {
      let query = supabase
        .from('outputs')
        .select('*')
        .eq('profileId', profileId)
        .order('createdAt', { ascending: false });

      if (options.outputType) {
        query = query.eq('outputType', options.outputType);
      }

      if (options.format) {
        query = query.eq('format', options.format);
      }

      const { data, error } = await query;

      if (error) {
        logger.error('Error fetching outputs for profile', { error, profileId, options });
        throw new AppError(`Failed to fetch outputs: ${error.message}`, 400);
      }

      return data as Output[];
    } catch (error) {
      logger.error('Error in getOutputsForProfile', { error, profileId, options });
      throw error instanceof AppError ? error : new AppError('Failed to fetch outputs', 500);
    }
  }

  /**
   * Create a new output
   */
  async createOutput(output: Omit<Output, 'id' | 'createdAt' | 'updatedAt'>): Promise<Output> {
    try {
      const { data, error } = await supabase
        .from('outputs')
        .insert([{
          ...output,
          createdAt: new Date(),
          updatedAt: new Date()
        }])
        .select()
        .single();

      if (error) {
        logger.error('Error creating output', { error, output });
        throw new AppError(`Failed to create output: ${error.message}`, 400);
      }

      return data as Output;
    } catch (error) {
      logger.error('Error in createOutput', { error, output });
      throw error instanceof AppError ? error : new AppError('Failed to create output', 500);
    }
  }

  /**
   * Update an existing output
   */
  async updateOutput(outputId: string, updates: Partial<Output>): Promise<Output> {
    try {
      const { data, error } = await supabase
        .from('outputs')
        .update({
          ...updates,
          updatedAt: new Date()
        })
        .eq('id', outputId)
        .select()
        .single();

      if (error) {
        logger.error('Error updating output', { error, outputId, updates });
        throw new AppError(`Failed to update output: ${error.message}`, 400);
      }

      return data as Output;
    } catch (error) {
      logger.error('Error in updateOutput', { error, outputId, updates });
      throw error instanceof AppError ? error : new AppError('Failed to update output', 500);
    }
  }

  /**
   * Delete an output
   */
  async deleteOutput(outputId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('outputs')
        .delete()
        .eq('id', outputId);

      if (error) {
        logger.error('Error deleting output', { error, outputId });
        throw new AppError(`Failed to delete output: ${error.message}`, 400);
      }
    } catch (error) {
      logger.error('Error in deleteOutput', { error, outputId });
      throw error instanceof AppError ? error : new AppError('Failed to delete output', 500);
    }
  }

  /**
   * Generate a multi-perspective view based on profile data and context
   */
  async generateMultiPerspectiveView(profileId: string, context: string, industry?: string): Promise<Output> {
    try {
      logger.info('Generating multi-perspective view', { profileId, context, industry });
      
      // Get complete profile data
      const profileData = await profileService.getCompleteProfile(profileId);
      
      // Get traits for the profile
      const traits = await traitService.getTraitsForProfile(profileId);
      
      // Define perspectives based on context
      const perspectives = this.getPerspectivesForContext(context);
      
      // Generate content for each perspective
      const perspectiveContent: Record<string, any> = {};
      
      for (const perspective of perspectives) {
        perspectiveContent[perspective.id] = this.generatePerspectiveContent(
          perspective, 
          profileData, 
          traits, 
          industry
        );
      }
      
      // Create the output
      const output = await this.createOutput({
        profileId,
        title: `${context} Perspective${perspectives.length > 1 ? 's' : ''}`,
        description: `Multi-perspective view of your profile for ${context}${industry ? ` in ${industry}` : ''}`,
        outputType: 'cv',
        format: 'interactive',
        context,
        industry,
        data: {
          perspectives: perspectiveContent,
          metadata: {
            generatedAt: new Date().toISOString(),
            profileVersion: profileData.profile.updatedAt,
            perspectiveCount: perspectives.length
          }
        }
      });
      
      return output;
    } catch (error) {
      logger.error('Error in generateMultiPerspectiveView', { error, profileId, context, industry });
      throw error instanceof AppError ? error : new AppError('Failed to generate multi-perspective view', 500);
    }
  }

  /**
   * Generate a narrative format based on profile data and context
   */
  async generateNarrativeFormat(profileId: string, context: string, industry?: string): Promise<Output> {
    try {
      logger.info('Generating narrative format', { profileId, context, industry });
      
      // Get complete profile data
      const profileData = await profileService.getCompleteProfile(profileId);
      
      // Get traits for the profile
      const traits = await traitService.getTraitsForProfile(profileId);
      
      // Generate narrative sections
      const narrativeSections = this.generateNarrativeSections(
        profileData, 
        traits, 
        context, 
        industry
      );
      
      // Create the output
      const output = await this.createOutput({
        profileId,
        title: `${context} Narrative`,
        description: `Narrative presentation of your profile for ${context}${industry ? ` in ${industry}` : ''}`,
        outputType: 'pitch',
        format: 'web',
        context,
        industry,
        data: {
          narrative: narrativeSections,
          metadata: {
            generatedAt: new Date().toISOString(),
            profileVersion: profileData.profile.updatedAt,
            wordCount: this.countWords(narrativeSections)
          }
        }
      });
      
      return output;
    } catch (error) {
      logger.error('Error in generateNarrativeFormat', { error, profileId, context, industry });
      throw error instanceof AppError ? error : new AppError('Failed to generate narrative format', 500);
    }
  }

  /**
   * Generate a CV format based on profile data and industry
   */
  async generateCVFormat(profileId: string, industry: string): Promise<Output> {
    try {
      logger.info('Generating CV format', { profileId, industry });
      
      // Get complete profile data
      const profileData = await profileService.getCompleteProfile(profileId);
      
      // Get traits for the profile
      const traits = await traitService.getTraitsForProfile(profileId);
      
      // Get industry-specific requirements
      const industryRequirements = this.getIndustryRequirements(industry);
      
      // Filter and prioritize experiences based on industry
      const prioritizedExperiences = this.prioritizeExperiencesForIndustry(
        profileData.experiences, 
        industryRequirements
      );
      
      // Filter and prioritize skills based on industry
      const prioritizedSkills = this.prioritizeSkillsForIndustry(
        profileData.skills, 
        industryRequirements
      );
      
      // Filter and prioritize projects based on industry
      const prioritizedProjects = this.prioritizeProjectsForIndustry(
        profileData.projects, 
        industryRequirements
      );
      
      // Generate industry-specific summary
      const industrySummary = this.generateIndustrySummary(
        profileData.profile, 
        traits, 
        industry
      );
      
      // Create the output
      const output = await this.createOutput({
        profileId,
        title: `${industry} CV`,
        description: `Tailored CV for the ${industry} industry`,
        outputType: 'cv',
        format: 'pdf',
        context: 'industry-specific',
        industry,
        data: {
          profile: {
            ...profileData.profile,
            summary: industrySummary
          },
          experiences: prioritizedExperiences,
          skills: prioritizedSkills,
          projects: prioritizedProjects,
          education: profileData.education,
          traits: traits.filter(t => t.score >= 70), // Only include high-scoring traits
          metadata: {
            generatedAt: new Date().toISOString(),
            profileVersion: profileData.profile.updatedAt,
            tailoredFor: industry
          }
        }
      });
      
      return output;
    } catch (error) {
      logger.error('Error in generateCVFormat', { error, profileId, industry });
      throw error instanceof AppError ? error : new AppError('Failed to generate CV format', 500);
    }
  }

  /**
   * Get perspectives for a given context
   */
  private getPerspectivesForContext(context: string): Array<{id: string, name: string, description: string}> {
    // Define perspectives based on context
    const perspectivesByContext: Record<string, Array<{id: string, name: string, description: string}>> = {
      'leadership': [
        {
          id: 'strategic',
          name: 'Strategic Leader',
          description: 'Focuses on vision, direction-setting, and long-term planning'
        },
        {
          id: 'operational',
          name: 'Operational Leader',
          description: 'Emphasizes execution, efficiency, and process optimization'
        },
        {
          id: 'transformational',
          name: 'Transformational Leader',
          description: 'Highlights change management, innovation, and organizational development'
        },
        {
          id: 'team',
          name: 'Team Leader',
          description: 'Focuses on team building, talent development, and collaboration'
        }
      ],
      'technical': [
        {
          id: 'architect',
          name: 'System Architect',
          description: 'Emphasizes design thinking, system integration, and technical vision'
        },
        {
          id: 'specialist',
          name: 'Technical Specialist',
          description: 'Focuses on deep expertise in specific technologies or domains'
        },
        {
          id: 'innovator',
          name: 'Technical Innovator',
          description: 'Highlights creative problem-solving and cutting-edge solutions'
        },
        {
          id: 'implementer',
          name: 'Implementation Expert',
          description: 'Emphasizes practical execution, reliability, and technical delivery'
        }
      ],
      'business': [
        {
          id: 'strategist',
          name: 'Business Strategist',
          description: 'Focuses on market positioning, competitive advantage, and growth strategies'
        },
        {
          id: 'operator',
          name: 'Business Operator',
          description: 'Emphasizes operational efficiency, process optimization, and business metrics'
        },
        {
          id: 'innovator',
          name: 'Business Innovator',
          description: 'Highlights business model innovation, new market development, and disruption'
        },
        {
          id: 'relationship',
          name: 'Relationship Builder',
          description: 'Focuses on stakeholder management, partnerships, and client relationships'
        }
      ],
      'project': [
        {
          id: 'manager',
          name: 'Project Manager',
          description: 'Emphasizes planning, coordination, and delivery of successful projects'
        },
        {
          id: 'technical',
          name: 'Technical Lead',
          description: 'Focuses on technical direction, architecture, and implementation'
        },
        {
          id: 'stakeholder',
          name: 'Stakeholder Manager',
          description: 'Highlights communication, expectation management, and relationship building'
        },
        {
          id: 'innovator',
          name: 'Project Innovator',
          description: 'Emphasizes creative approaches, problem-solving, and continuous improvement'
        }
      ],
      'consulting': [
        {
          id: 'advisor',
          name: 'Strategic Advisor',
          description: 'Focuses on providing high-level guidance and strategic recommendations'
        },
        {
          id: 'specialist',
          name: 'Domain Specialist',
          description: 'Emphasizes deep expertise in specific industries or functional areas'
        },
        {
          id: 'implementer',
          name: 'Implementation Consultant',
          description: 'Highlights practical execution, change management, and solution delivery'
        },
        {
          id: 'facilitator',
          name: 'Process Facilitator',
          description: 'Focuses on guiding clients through complex processes and decision-making'
        }
      ]
    };
    
    // Return perspectives for the given context, or default to leadership if not found
    return perspectivesByContext[context.toLowerCase()] || perspectivesByContext['leadership'];
  }

  /**
   * Generate content for a specific perspective
   */
  private generatePerspectiveContent(
    perspective: {id: string, name: string, description: string},
    profileData: any,
    traits: any[],
    industry?: string
  ): any {
    // Select and prioritize experiences based on perspective
    const relevantExperiences = this.filterExperiencesForPerspective(
      profileData.experiences,
      perspective.id
    );
    
    // Select and prioritize skills based on perspective
    const relevantSkills = this.filterSkillsForPerspective(
      profileData.skills,
      perspective.id
    );
    
    // Select and prioritize projects based on perspective
    const relevantProjects = this.filterProjectsForPerspective(
      profileData.projects,
      perspective.id
    );
    
    // Generate perspective-specific summary
    const summary = this.generatePerspectiveSummary(
      profileData.profile,
      traits,
      perspective,
      industry
    );
    
    // Generate key achievements for this perspective
    const achievements = this.generateKeyAchievements(
      relevantExperiences,
      relevantProjects,
      perspective
    );
    
    // Generate value proposition for this perspective
    const valueProposition = this.generateValueProposition(
      profileData.profile,
      traits,
      perspective,
      industry
    );
    
    return {
      name: perspective.name,
      description: perspective.description,
      summary,
      valueProposition,
      experiences: relevantExperiences,
      skills: relevantSkills,
      projects: relevantProjects,
      achievements,
      traits: this.getRelevantTraitsForPerspective(traits, perspective.id)
    };
  }

  /**
   * Filter experiences for a specific perspective
   */
  private filterExperiencesForPerspective(experiences: any[], perspectiveId: string): any[] {
    // Define keywords for each perspective
    const perspectiveKeywords: Record<string, string[]> = {
      // Leadership perspectives
      'strategic': ['strategy', 'vision', 'direction', 'leadership', 'executive', 'planning', 'roadmap'],
      'operational': ['operations', 'efficiency', 'process', 'execution', 'implementation', 'management'],
      'transformational': ['transformation', 'change', 'innovation', 'redesign', 'modernization'],
      'team': ['team', 'mentor', 'coach', 'talent', 'development', 'collaboration', 'people'],
      
      // Technical perspectives
      'architect': ['architecture', 'design', 'system', 'integration', 'platform', 'infrastructure'],
      'specialist': ['specialist', 'expert', 'technical', 'technology', 'development', 'programming'],
      'innovator': ['innovation', 'research', 'prototype', 'cutting-edge', 'emerging', 'new'],
      'implementer': ['implementation', 'delivery', 'deployment', 'production', 'reliability'],
      
      // Business perspectives
      'strategist': ['strategy', 'market', 'competitive', 'growth', 'business development'],
      'operator': ['operations', 'metrics', 'kpi', 'efficiency', 'process', 'optimization'],
      'innovator': ['innovation', 'disruption', 'new market', 'business model', 'transformation'],
      'relationship': ['client', 'partner', 'stakeholder', 'relationship', 'account', 'customer'],
      
      // Project perspectives
      'manager': ['project', 'program', 'management', 'planning', 'delivery', 'coordination'],
      'technical': ['technical', 'architecture', 'development', 'engineering', 'implementation'],
      'stakeholder': ['stakeholder', 'communication', 'expectation', 'relationship', 'client'],
      'innovator': ['innovation', 'improvement', 'solution', 'creative', 'problem-solving'],
      
      // Consulting perspectives
      'advisor': ['advisory', 'strategy', 'recommendation', 'guidance', 'consulting'],
      'specialist': ['specialist', 'expert', 'domain', 'industry', 'functional'],
      'implementer': ['implementation', 'execution', 'delivery', 'solution', 'change'],
      'facilitator': ['facilitation', 'workshop', 'process', 'decision', 'collaboration']
    };
    
    // Get keywords for the perspective
    const keywords = perspectiveKeywords[perspectiveId] || [];
    
    // Score experiences based on relevance to the perspective
    const scoredExperiences = experiences.map(exp => {
      // Initialize score
      let score = 0;
      
      // Check title for keywords
      const title = exp.title.toLowerCase();
      score += keywords.filter(kw => title.includes(kw)).length * 3;
      
      // Check description for keywords
      const description = exp.description.toLowerCase();
      score += keywords.filter(kw => description.includes(kw)).length * 2;
      
      // Check achievements for keywords
      if (exp.achievements) {
        const achievementsText = exp.achievements.join(' ').toLowerCase();
        score += keywords.filter(kw => achievementsText.includes(kw)).length * 2;
      }
      
      // Check skills for keywords
      if (exp.skills) {
        const skillsText = exp.skills.join(' ').toLowerCase();
        score += keywords.filter(kw => skillsText.includes(kw)).length;
      }
      
      return { ...exp, relevanceScore: score };
    });
    
    // Sort by relevance score (descending) and then by start date (descending)
    scoredExperiences.sort((a, b) => {
      if (b.relevanceScore !== a.relevanceScore) {
        return b.relevanceScore - a.relevanceScore;
      }
      return new Date(b.startDate).getTime() - new Date(a.startDate).getTime();
    });
    
    // Return top experiences, removing the relevance score
    return scoredExperiences
      .slice(0, 5)
      .map(({ relevanceScore, ...exp }) => exp);
  }

  /**
   * Filter skills for a specific perspective
   */
  private filterSkillsForPerspective(skills: any[], perspectiveId: string): any[] {
    // Define relevant skill categories for each perspective
    const perspectiveCategories: Record<string, string[]> = {
      // Leadership perspectives
      'strategic': ['leadership', 'strategy', 'business', 'management', 'planning'],
      'operational': ['operations', 'management', 'process', 'efficiency', 'organization'],
      'transformational': ['change management', 'innovation', 'leadership', 'strategy'],
      'team': ['leadership', 'communication', 'people management', 'coaching', 'collaboration'],
      
      // Technical perspectives
      'architect': ['architecture', 'design', 'infrastructure', 'systems', 'integration'],
      'specialist': ['development', 'programming', 'technical', 'specialized', 'tools'],
      'innovator': ['innovation', 'research', 'emerging technologies', 'development'],
      'implementer': ['development', 'deployment', 'operations', 'reliability', 'technical'],
      
      // Business perspectives
      'strategist': ['strategy', 'business', 'analysis', 'planning', 'market'],
      'operator': ['operations', 'process', 'management', 'metrics', 'efficiency'],
      'innovator': ['innovation', 'business', 'strategy', 'creativity'],
      'relationship': ['communication', 'client management', 'relationship', 'negotiation'],
      
      // Project perspectives
      'manager': ['project management', 'planning', 'organization', 'coordination'],
      'technical': ['technical', 'development', 'architecture', 'engineering'],
      'stakeholder': ['communication', 'relationship', 'presentation', 'negotiation'],
      'innovator': ['innovation', 'problem solving', 'creativity', 'improvement'],
      
      // Consulting perspectives
      'advisor': ['strategy', 'advisory', 'analysis', 'business', 'consulting'],
      'specialist': ['specialized', 'technical', 'domain', 'industry', 'functional'],
      'implementer': ['implementation', 'project management', 'change management'],
      'facilitator': ['facilitation', 'communication', 'workshop', 'collaboration']
    };
    
    // Get relevant categories for the perspective
    const relevantCategories = perspectiveCategories[perspectiveId] || [];
    
    // Score skills based on relevance to the perspective
    const scoredSkills = skills.map(skill => {
      // Initialize score
      let score = 0;
      
      // Check if skill category matches any relevant category
      const category = skill.category.toLowerCase();
      score += relevantCategories.filter(cat => category.includes(cat)).length * 3;
      
      // Check if skill name matches any relevant category
      const name = skill.name.toLowerCase();
      score += relevantCategories.filter(cat => name.includes(cat)).length * 2;
      
      // Add points for skill level
      score += skill.level || 0;
      
      return { ...skill, relevanceScore: score };
    });
    
    // Sort by relevance score (descending) and then by level (descending)
    scoredSkills.sort((a, b) => {
      if (b.relevanceScore !== a.relevanceScore) {
        return b.relevanceScore - a.relevanceScore;
      }
      return (b.level || 0) - (a.level || 0);
    });
    
    // Return top skills, removing the relevance score
    return scoredSkills
      .slice(0, 10)
      .map(({ relevanceScore, ...skill }) => skill);
  }

  /**
   * Filter projects for a specific perspective
   */
  private filterProjectsForPerspective(projects: any[], perspectiveId: string): any[] {
    // Define keywords for each perspective (similar to experiences)
    const perspectiveKeywords: Record<string, string[]> = {
      // Leadership perspectives
      'strategic': ['strategy', 'vision', 'direction', 'leadership', 'planning', 'roadmap'],
      'operational': ['operations', 'efficiency', 'process', 'execution', 'implementation'],
      'transformational': ['transformation', 'change', 'innovation', 'redesign', 'modernization'],
      'team': ['team', 'collaboration', 'people', 'coordination', 'management'],
      
      // Technical perspectives
      'architect': ['architecture', 'design', 'system', 'integration', 'platform', 'infrastructure'],
      'specialist': ['specialist', 'technical', 'technology', 'development', 'programming'],
      'innovator': ['innovation', 'research', 'prototype', 'cutting-edge', 'emerging'],
      'implementer': ['implementation', 'delivery', 'deployment', 'production', 'reliability'],
      
      // Business perspectives
      'strategist': ['strategy', 'market', 'competitive', 'growth', 'business'],
      'operator': ['operations', 'metrics', 'efficiency', 'process', 'optimization'],
      'innovator': ['innovation', 'disruption', 'new', 'business model', 'transformation'],
      'relationship': ['client', 'partner', 'stakeholder', 'relationship', 'customer'],
      
      // Project perspectives
      'manager': ['project', 'program', 'management', 'planning', 'delivery', 'coordination'],
      'technical': ['technical', 'architecture', 'development', 'engineering', 'implementation'],
      'stakeholder': ['stakeholder', 'communication', 'expectation', 'relationship', 'client'],
      'innovator': ['innovation', 'improvement', 'solution', 'creative', 'problem-solving'],
      
      // Consulting perspectives
      'advisor': ['advisory', 'strategy', 'recommendation', 'guidance', 'consulting'],
      'specialist': ['specialist', 'expert', 'domain', 'industry', 'functional'],
      'implementer': ['implementation', 'execution', 'delivery', 'solution', 'change'],
      'facilitator': ['facilitation', 'workshop', 'process', 'decision', 'collaboration']
    };
    
    // Get keywords for the perspective
    const keywords = perspectiveKeywords[perspectiveId] || [];
    
    // Score projects based on relevance to the perspective
    const scoredProjects = projects.map(project => {
      // Initialize score
      let score = 0;
      
      // Check title for keywords
      const title = project.title.toLowerCase();
      score += keywords.filter(kw => title.includes(kw)).length * 3;
      
      // Check description for keywords
      const description = project.description.toLowerCase();
      score += keywords.filter(kw => description.includes(kw)).length * 2;
      
      // Check outcomes for keywords
      if (project.outcomes) {
        const outcomesText = project.outcomes.join(' ').toLowerCase();
        score += keywords.filter(kw => outcomesText.includes(kw)).length * 2;
      }
      
      // Check skills for keywords
      if (project.skills) {
        const skillsText = project.skills.join(' ').toLowerCase();
        score += keywords.filter(kw => skillsText.includes(kw)).length;
      }
      
      return { ...project, relevanceScore: score };
    });
    
    // Sort by relevance score (descending) and then by start date (descending)
    scoredProjects.sort((a, b) => {
      if (b.relevanceScore !== a.relevanceScore) {
        return b.relevanceScore - a.relevanceScore;
      }
      return new Date(b.startDate || '2099-01-01').getTime() - new Date(a.startDate || '2099-01-01').getTime();
    });
    
    // Return top projects, removing the relevance score
    return scoredProjects
      .slice(0, 3)
      .map(({ relevanceScore, ...project }) => project);
  }

  /**
   * Generate a perspective-specific summary
   */
  private generatePerspectiveSummary(
    profile: any,
    traits: any[],
    perspective: {id: string, name: string, description: string},
    industry?: string
  ): string {
    // Get relevant traits for this perspective
    const relevantTraits = this.getRelevantTraitsForPerspective(traits, perspective.id);
    
    // Get industry-specific language if available
    const industryTerms = industry ? this.getIndustryTerms(industry) : { terms: [], focus: [] };
    
    // Generate summary based on perspective
    switch (perspective.id) {
      case 'strategic':
        return `Strategic leader with a proven track record of setting vision and direction${industry ? ` in the ${industry} industry` : ''}. Combines ${this.getTraitPhrase(relevantTraits)} to drive organizational success through clear strategic planning and execution. ${profile.summary ? profile.summary.split('.')[0] + '.' : ''}`;
      
      case 'operational':
        return `Results-driven operational leader focused on efficiency and process optimization${industry ? ` within ${industry} environments` : ''}. Leverages ${this.getTraitPhrase(relevantTraits)} to deliver consistent results and operational excellence. ${profile.summary ? profile.summary.split('.')[0] + '.' : ''}`;
      
      case 'transformational':
        return `Change agent and transformational leader with expertise in driving organizational evolution${industry ? ` in ${industry}` : ''}. Combines ${this.getTraitPhrase(relevantTraits)} to lead successful transformation initiatives and foster innovation. ${profile.summary ? profile.summary.split('.')[0] + '.' : ''}`;
      
      case 'team':
        return `People-focused leader with a talent for building and developing high-performing teams${industry ? ` in ${industry} settings` : ''}. Utilizes ${this.getTraitPhrase(relevantTraits)} to create collaborative environments that drive results through empowered teams. ${profile.summary ? profile.summary.split('.')[0] + '.' : ''}`;
      
      case 'architect':
        return `Visionary system architect with expertise in designing scalable, resilient solutions${industry ? ` for ${industry}` : ''}. Combines ${this.getTraitPhrase(relevantTraits)} to create technical architectures that align with business objectives. ${profile.summary ? profile.summary.split('.')[0] + '.' : ''}`;
      
      case 'specialist':
        return `Technical specialist with deep expertise in ${industryTerms.terms.length > 0 ? industryTerms.terms.join(', ') : 'key technologies'}. Leverages ${this.getTraitPhrase(relevantTraits)} to deliver specialized solutions${industry ? ` in ${industry} contexts` : ''}. ${profile.summary ? profile.summary.split('.')[0] + '.' : ''}`;
      
      case 'innovator':
        return `Technical innovator with a passion for developing cutting-edge solutions${industry ? ` in ${industry}` : ''}. Combines ${this.getTraitPhrase(relevantTraits)} to drive innovation and solve complex problems with creative approaches. ${profile.summary ? profile.summary.split('.')[0] + '.' : ''}`;
      
      case 'implementer':
        return `Implementation expert focused on delivering reliable, high-quality technical solutions${industry ? ` for ${industry}` : ''}. Utilizes ${this.getTraitPhrase(relevantTraits)} to ensure successful execution and deployment of critical systems. ${profile.summary ? profile.summary.split('.')[0] + '.' : ''}`;
      
      // Add cases for other perspectives...
      
      default:
        return profile.summary || `Experienced professional with a diverse background${industry ? ` in ${industry}` : ''}.`;
    }
  }

  /**
   * Generate key achievements for a perspective
   */
  private generateKeyAchievements(
    experiences: any[],
    projects: any[],
    perspective: {id: string, name: string, description: string}
  ): string[] {
    const achievements: string[] = [];
    
    // Extract achievements from experiences
    for (const exp of experiences) {
      if (exp.achievements && exp.achievements.length > 0) {
        achievements.push(...exp.achievements);
      }
    }
    
    // Extract outcomes from projects
    for (const project of projects) {
      if (project.outcomes && project.outcomes.length > 0) {
        achievements.push(...project.outcomes);
      }
    }
    
    // Filter for relevance to perspective
    const perspectiveKeywords: Record<string, string[]> = {
      'strategic': ['strategy', 'vision', 'direction', 'growth', 'market'],
      'operational': ['efficiency', 'process', 'cost', 'productivity', 'performance'],
      'transformational': ['transformation', 'change', 'innovation', 'modernization'],
      'team': ['team', 'talent', 'development', 'collaboration', 'culture'],
      // Add keywords for other perspectives...
    };
    
    const keywords = perspectiveKeywords[perspective.id] || [];
    
    // Score achievements by relevance
    const scoredAchievements = achievements.map(achievement => {
      const text = achievement.toLowerCase();
      const score = keywords.filter(kw => text.includes(kw)).length;
      return { text: achievement, score };
    });
    
    // Sort by relevance score (descending)
    scoredAchievements.sort((a, b) => b.score - a.score);
    
    // Return top achievements
    return scoredAchievements
      .slice(0, 5)
      .map(a => a.text);
  }

  /**
   * Generate a value proposition for a perspective
   */
  private generateValueProposition(
    profile: any,
    traits: any[],
    perspective: {id: string, name: string, description: string},
    industry?: string
  ): string {
    // Get relevant traits for this perspective
    const relevantTraits = this.getRelevantTraitsForPerspective(traits, perspective.id);
    
    // Get industry-specific language if available
    const industryTerms = industry ? this.getIndustryTerms(industry) : { terms: [], focus: [] };
    
    // Generate value proposition based on perspective
    switch (perspective.id) {
      case 'strategic':
        return `A strategic leader who combines ${this.getTraitPhrase(relevantTraits)} to develop and execute vision-driven strategies${industry ? ` in ${industry}` : ''}. Proven ability to align organizational capabilities with market opportunities, resulting in sustainable growth and competitive advantage.`;
      
      case 'operational':
        return `An operational leader who leverages ${this.getTraitPhrase(relevantTraits)} to optimize processes and drive efficiency${industry ? ` in ${industry} environments` : ''}. Demonstrated success in improving organizational performance through systematic approaches to operations management.`;
      
      case 'transformational':
        return `A transformational leader who utilizes ${this.getTraitPhrase(relevantTraits)} to drive organizational change and innovation${industry ? ` in ${industry}` : ''}. Proven track record of successfully leading complex transformation initiatives that deliver measurable business results.`;
      
      case 'team':
        return `A team leader who combines ${this.getTraitPhrase(relevantTraits)} to build and develop high-performing teams${industry ? ` in ${industry} settings` : ''}. Demonstrated ability to foster collaborative environments that maximize talent potential and drive collective success.`;
      
      // Add cases for other perspectives...
      
      default:
        return `A versatile professional who brings ${this.getTraitPhrase(relevantTraits)} to deliver exceptional results${industry ? ` in ${industry}` : ''}.`;
    }
  }

  /**
   * Get relevant traits for a perspective
   */
  private getRelevantTraitsForPerspective(traits: any[], perspectiveId: string): any[] {
    // Define relevant trait names for each perspective
    const perspectiveTraits: Record<string, string[]> = {
      'strategic': ['Strategic Thinking', 'Leadership', 'Innovation', 'Problem Solving'],
      'operational': ['Problem Solving', 'Adaptability', 'Technical Expertise', 'Leadership'],
      'transformational': ['Innovation', 'Adaptability', 'Leadership', 'Strategic Thinking'],
      'team': ['Leadership', 'Communication', 'Adaptability', 'Problem Solving'],
      'architect': ['Technical Expertise', 'Strategic Thinking', 'Innovation', 'Problem Solving'],
      'specialist': ['Technical Expertise', 'Problem Solving', 'Adaptability', 'Communication'],
      'innovator': ['Innovation', 'Technical Expertise', 'Problem Solving', 'Strategic Thinking'],
      'implementer': ['Technical Expertise', 'Problem Solving', 'Adaptability', 'Communication'],
      // Add mappings for other perspectives...
    };
    
    // Get relevant trait names for the perspective
    const relevantTraitNames = perspectiveTraits[perspectiveId] || [];
    
    // Filter traits by name and sort by score (descending)
    return traits
      .filter(trait => relevantTraitNames.includes(trait.name))
      .sort((a, b) => b.score - a.score);
  }

  /**
   * Get a phrase describing traits
   */
  private getTraitPhrase(traits: any[]): string {
    if (traits.length === 0) {
      return 'diverse skills and experience';
    }
    
    if (traits.length === 1) {
      return `strong ${traits[0].name.toLowerCase()}`;
    }
    
    if (traits.length === 2) {
      return `${traits[0].name.toLowerCase()} and ${traits[1].name.toLowerCase()}`;
    }
    
    const traitNames = traits.map(t => t.name.toLowerCase());
    const lastTrait = traitNames.pop();
    return `${traitNames.join(', ')}, and ${lastTrait}`;
  }

  /**
   * Get industry-specific terms and focus areas
   */
  private getIndustryTerms(industry: string): { terms: string[], focus: string[] } {
    const industryTerms: Record<string, { terms: string[], focus: string[] }> = {
      'technology': {
        terms: ['cloud computing', 'software development', 'agile methodologies', 'DevOps', 'cybersecurity'],
        focus: ['innovation', 'scalability', 'technical excellence', 'rapid iteration']
      },
      'finance': {
        terms: ['financial services', 'risk management', 'regulatory compliance', 'fintech', 'investment strategies'],
        focus: ['security', 'compliance', 'accuracy', 'risk mitigation']
      },
      'healthcare': {
        terms: ['healthcare IT', 'patient care', 'clinical systems', 'HIPAA compliance', 'medical informatics'],
        focus: ['patient outcomes', 'compliance', 'data security', 'interoperability']
      },
      'retail': {
        terms: ['omnichannel', 'customer experience', 'e-commerce', 'supply chain', 'merchandising'],
        focus: ['customer satisfaction', 'operational efficiency', 'sales growth', 'brand loyalty']
      },
      'consulting': {
        terms: ['management consulting', 'strategic advisory', 'business transformation', 'client solutions', 'industry expertise'],
        focus: ['client outcomes', 'thought leadership', 'problem-solving', 'relationship management']
      }
      // Add other industries as needed
    };
    
    return industryTerms[industry.toLowerCase()] || { terms: [], focus: [] };
  }

  /**
   * Get industry-specific requirements
   */
  private getIndustryRequirements(industry: string): { skills: string[], focus: string[] } {
    const industryRequirements: Record<string, { skills: string[], focus: string[] }> = {
      'technology': {
        skills: ['software development', 'cloud', 'architecture', 'agile', 'DevOps', 'cybersecurity'],
        focus: ['innovation', 'technical expertise', 'scalability', 'rapid delivery']
      },
      'finance': {
        skills: ['risk management', 'compliance', 'financial systems', 'security', 'data analysis'],
        focus: ['security', 'compliance', 'reliability', 'accuracy']
      },
      'healthcare': {
        skills: ['healthcare IT', 'HIPAA', 'clinical systems', 'interoperability', 'data security'],
        focus: ['patient care', 'compliance', 'security', 'reliability']
      },
      'retail': {
        skills: ['e-commerce', 'customer experience', 'supply chain', 'digital marketing', 'analytics'],
        focus: ['customer experience', 'operational efficiency', 'omnichannel', 'scalability']
      },
      'consulting': {
        skills: ['advisory', 'project management', 'business analysis', 'industry expertise', 'client management'],
        focus: ['client outcomes', 'expertise', 'problem-solving', 'communication']
      }
      // Add other industries as needed
    };
    
    return industryRequirements[industry.toLowerCase()] || { skills: [], focus: [] };
  }

  /**
   * Prioritize experiences for an industry
   */
  private prioritizeExperiencesForIndustry(experiences: any[], industryRequirements: { skills: string[], focus: string[] }): any[] {
    // Score experiences based on relevance to industry
    const scoredExperiences = experiences.map(exp => {
      // Initialize score
      let score = 0;
      
      // Check title and company for industry relevance
      const titleAndCompany = `${exp.title} ${exp.company}`.toLowerCase();
      score += industryRequirements.skills.filter(skill => titleAndCompany.includes(skill.toLowerCase())).length * 3;
      
      // Check description for industry relevance
      const description = exp.description.toLowerCase();
      score += industryRequirements.skills.filter(skill => description.includes(skill.toLowerCase())).length * 2;
      score += industryRequirements.focus.filter(focus => description.includes(focus.toLowerCase())).length * 2;
      
      // Check skills for industry relevance
      if (exp.skills) {
        const skillsText = exp.skills.join(' ').toLowerCase();
        score += industryRequirements.skills.filter(skill => skillsText.includes(skill.toLowerCase())).length * 3;
      }
      
      // Check achievements for industry relevance
      if (exp.achievements) {
        const achievementsText = exp.achievements.join(' ').toLowerCase();
        score += industryRequirements.skills.filter(skill => achievementsText.includes(skill.toLowerCase())).length * 2;
        score += industryRequirements.focus.filter(focus => achievementsText.includes(focus.toLowerCase())).length * 2;
      }
      
      return { ...exp, relevanceScore: score };
    });
    
    // Sort by relevance score (descending) and then by start date (descending)
    scoredExperiences.sort((a, b) => {
      if (b.relevanceScore !== a.relevanceScore) {
        return b.relevanceScore - a.relevanceScore;
      }
      return new Date(b.startDate).getTime() - new Date(a.startDate).getTime();
    });
    
    // Return all experiences, but with the most relevant first, removing the relevance score
    return scoredExperiences.map(({ relevanceScore, ...exp }) => exp);
  }

  /**
   * Prioritize skills for an industry
   */
  private prioritizeSkillsForIndustry(skills: any[], industryRequirements: { skills: string[], focus: string[] }): any[] {
    // Score skills based on relevance to industry
    const scoredSkills = skills.map(skill => {
      // Initialize score
      let score = 0;
      
      // Check skill name for industry relevance
      const name = skill.name.toLowerCase();
      score += industryRequirements.skills.filter(s => name.includes(s.toLowerCase())).length * 3;
      
      // Check skill category for industry relevance
      const category = skill.category.toLowerCase();
      score += industryRequirements.skills.filter(s => category.includes(s.toLowerCase())).length * 2;
      
      // Add points for skill level
      score += skill.level || 0;
      
      return { ...skill, relevanceScore: score };
    });
    
    // Sort by relevance score (descending) and then by level (descending)
    scoredSkills.sort((a, b) => {
      if (b.relevanceScore !== a.relevanceScore) {
        return b.relevanceScore - a.relevanceScore;
      }
      return (b.level || 0) - (a.level || 0);
    });
    
    // Return all skills, but with the most relevant first, removing the relevance score
    return scoredSkills.map(({ relevanceScore, ...skill }) => skill);
  }

  /**
   * Prioritize projects for an industry
   */
  private prioritizeProjectsForIndustry(projects: any[], industryRequirements: { skills: string[], focus: string[] }): any[] {
    // Score projects based on relevance to industry
    const scoredProjects = projects.map(project => {
      // Initialize score
      let score = 0;
      
      // Check title for industry relevance
      const title = project.title.toLowerCase();
      score += industryRequirements.skills.filter(skill => title.includes(skill.toLowerCase())).length * 3;
      score += industryRequirements.focus.filter(focus => title.includes(focus.toLowerCase())).length * 2;
      
      // Check description for industry relevance
      const description = project.description.toLowerCase();
      score += industryRequirements.skills.filter(skill => description.includes(skill.toLowerCase())).length * 2;
      score += industryRequirements.focus.filter(focus => description.includes(focus.toLowerCase())).length * 2;
      
      // Check skills for industry relevance
      if (project.skills) {
        const skillsText = project.skills.join(' ').toLowerCase();
        score += industryRequirements.skills.filter(skill => skillsText.includes(skill.toLowerCase())).length * 3;
      }
      
      // Check outcomes for industry relevance
      if (project.outcomes) {
        const outcomesText = project.outcomes.join(' ').toLowerCase();
        score += industryRequirements.skills.filter(skill => outcomesText.includes(skill.toLowerCase())).length * 2;
        score += industryRequirements.focus.filter(focus => outcomesText.includes(focus.toLowerCase())).length * 2;
      }
      
      return { ...project, relevanceScore: score };
    });
    
    // Sort by relevance score (descending) and then by start date (descending)
    scoredProjects.sort((a, b) => {
      if (b.relevanceScore !== a.relevanceScore) {
        return b.relevanceScore - a.relevanceScore;
      }
      return new Date(b.startDate || '2099-01-01').getTime() - new Date(a.startDate || '2099-01-01').getTime();
    });
    
    // Return all projects, but with the most relevant first, removing the relevance score
    return scoredProjects.map(({ relevanceScore, ...project }) => project);
  }

  /**
   * Generate an industry-specific summary
   */
  private generateIndustrySummary(profile: any, traits: any[], industry: string): string {
    // Get industry-specific terms and focus areas
    const industryTerms = this.getIndustryTerms(industry);
    
    // Get top traits
    const topTraits = [...traits].sort((a, b) => b.score - a.score).slice(0, 3);
    
    // Generate industry-specific summary
    const originalSummary = profile.summary || '';
    
    return `Experienced professional with expertise in ${industryTerms.terms.join(', ')}. Combines ${this.getTraitPhrase(topTraits)} to deliver exceptional results with a focus on ${industryTerms.focus.join(', ')}. ${originalSummary}`;
  }

  /**
   * Generate narrative sections for a profile
   */
  private generateNarrativeSections(
    profileData: any,
    traits: any[],
    context: string,
    industry?: string
  ): any[] {
    // Define section types based on context
    const sectionTypes: Record<string, string[]> = {
      'leadership': ['introduction', 'leadership-journey', 'leadership-philosophy', 'achievements', 'vision'],
      'technical': ['introduction', 'technical-expertise', 'problem-solving', 'innovation', 'technical-vision'],
      'business': ['introduction', 'business-acumen', 'strategic-initiatives', 'results', 'market-perspective'],
      'project': ['introduction', 'project-approach', 'key-projects', 'challenges-overcome', 'methodologies'],
      'consulting': ['introduction', 'expertise-areas', 'client-success-stories', 'approach', 'value-proposition']
    };
    
    // Get section types for the context
    const sections = sectionTypes[context.toLowerCase()] || ['introduction', 'background', 'expertise', 'achievements', 'approach'];
    
    // Generate content for each section
    return sections.map(sectionType => {
      return {
        type: sectionType,
        title: this.getSectionTitle(sectionType),
        content: this.generateSectionContent(sectionType, profileData, traits, context, industry)
      };
    });
  }

  /**
   * Get section title
   */
  private getSectionTitle(sectionType: string): string {
    const titles: Record<string, string> = {
      'introduction': 'Professional Overview',
      'leadership-journey': 'Leadership Journey',
      'leadership-philosophy': 'Leadership Philosophy',
      'technical-expertise': 'Technical Expertise',
      'problem-solving': 'Problem-Solving Approach',
      'innovation': 'Innovation & Creativity',
      'technical-vision': 'Technical Vision',
      'business-acumen': 'Business Acumen',
      'strategic-initiatives': 'Strategic Initiatives',
      'results': 'Business Results',
      'market-perspective': 'Market Perspective',
      'project-approach': 'Project Management Approach',
      'key-projects': 'Key Projects',
      'challenges-overcome': 'Challenges Overcome',
      'methodologies': 'Methodologies & Frameworks',
      'expertise-areas': 'Areas of Expertise',
      'client-success-stories': 'Client Success Stories',
      'approach': 'Consulting Approach',
      'value-proposition': 'Value Proposition',
      'background': 'Professional Background',
      'expertise': 'Core Expertise',
      'achievements': 'Key Achievements',
      'vision': 'Future Vision'
    };
    
    return titles[sectionType] || sectionType.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  }

  /**
   * Generate section content
   */
  private generateSectionContent(
    sectionType: string,
    profileData: any,
    traits: any[],
    context: string,
    industry?: string
  ): string {
    // This would be replaced with actual content generation logic
    // For now, we'll return placeholder content based on section type
    
    // Get industry-specific terms if available
    const industryTerms = industry ? this.getIndustryTerms(industry) : { terms: [], focus: [] };
    
    // Get top traits
    const topTraits = [...traits].sort((a, b) => b.score - a.score).slice(0, 3);
    const traitPhrase = this.getTraitPhrase(topTraits);
    
    // Generate content based on section type
    switch (sectionType) {
      case 'introduction':
        return `${profileData.profile.summary || `Experienced professional with a background in ${industryTerms.terms.join(', ')}.`} Combines ${traitPhrase} to deliver exceptional results${industry ? ` in the ${industry} industry` : ''}.`;
      
      case 'leadership-journey':
        return `With a progressive career spanning ${this.calculateYearsOfExperience(profileData.experiences)} years, I've evolved from ${this.getEarliestRole(profileData.experiences)} to ${this.getLatestRole(profileData.experiences)}. Throughout this journey, I've developed a leadership style that emphasizes ${this.getLeadershipEmphasis(traits)} while adapting to the unique challenges of each role and organization.`;
      
      case 'technical-expertise':
        return `My technical foundation includes expertise in ${this.getTopSkills(profileData.skills, 5).join(', ')}. I've applied these skills across various contexts, from ${this.getProjectTypes(profileData.projects)} to ${this.getExperienceTypes(profileData.experiences)}. This diverse technical background enables me to approach problems with both depth and breadth of knowledge.`;
      
      // Add cases for other section types...
      
      default:
        return `This section provides information about ${sectionType.replace('-', ' ')}.`;
    }
  }

  /**
   * Calculate years of experience
   */
  private calculateYearsOfExperience(experiences: any[]): number {
    if (!experiences || experiences.length === 0) {
      return 0;
    }
    
    // Sort experiences by start date
    const sortedExperiences = [...experiences].sort((a, b) => 
      new Date(a.startDate).getTime() - new Date(b.startDate).getTime()
    );
    
    // Get earliest start date
    const earliestStart = new Date(sortedExperiences[0].startDate);
    
    // Calculate years from earliest start to now
    const now = new Date();
    return Math.floor((now.getTime() - earliestStart.getTime()) / (1000 * 60 * 60 * 24 * 365));
  }

  /**
   * Get earliest role
   */
  private getEarliestRole(experiences: any[]): string {
    if (!experiences || experiences.length === 0) {
      return 'entry-level positions';
    }
    
    // Sort experiences by start date
    const sortedExperiences = [...experiences].sort((a, b) => 
      new Date(a.startDate).getTime() - new Date(b.startDate).getTime()
    );
    
    // Return earliest role
    return sortedExperiences[0].title;
  }

  /**
   * Get latest role
   */
  private getLatestRole(experiences: any[]): string {
    if (!experiences || experiences.length === 0) {
      return 'current role';
    }
    
    // Sort experiences by start date (descending)
    const sortedExperiences = [...experiences].sort((a, b) => 
      new Date(b.startDate).getTime() - new Date(a.startDate).getTime()
    );
    
    // Return latest role
    return sortedExperiences[0].title;
  }

  /**
   * Get leadership emphasis based on traits
   */
  private getLeadershipEmphasis(traits: any[]): string {
    // Define leadership aspects
    const leadershipAspects = [
      'clear communication',
      'strategic thinking',
      'team empowerment',
      'innovation',
      'results orientation',
      'adaptability',
      'mentorship',
      'vision setting'
    ];
    
    // If no traits, return random aspects
    if (!traits || traits.length === 0) {
      const randomAspects = [...leadershipAspects].sort(() => 0.5 - Math.random()).slice(0, 3);
      return randomAspects.join(', ');
    }
    
    // Map traits to leadership aspects
    const traitToAspect: Record<string, string[]> = {
      'Leadership': ['team empowerment', 'mentorship', 'vision setting'],
      'Strategic Thinking': ['strategic thinking', 'vision setting', 'results orientation'],
      'Communication': ['clear communication', 'team empowerment', 'mentorship'],
      'Innovation': ['innovation', 'adaptability', 'vision setting'],
      'Problem Solving': ['results orientation', 'adaptability', 'innovation'],
      'Adaptability': ['adaptability', 'innovation', 'results orientation']
    };
    
    // Get aspects based on top traits
    const topTraits = [...traits].sort((a, b) => b.score - a.score).slice(0, 2);
    const aspects = new Set<string>();
    
    for (const trait of topTraits) {
      const traitAspects = traitToAspect[trait.name] || [];
      for (const aspect of traitAspects) {
        aspects.add(aspect);
      }
    }
    
    // Return aspects or default if none found
    return aspects.size > 0 
      ? Array.from(aspects).slice(0, 3).join(', ')
      : leadershipAspects.slice(0, 3).join(', ');
  }

  /**
   * Get top skills
   */
  private getTopSkills(skills: any[], count: number): string[] {
    if (!skills || skills.length === 0) {
      return ['relevant technologies', 'industry tools', 'professional methodologies'];
    }
    
    // Sort skills by level (descending)
    const sortedSkills = [...skills].sort((a, b) => (b.level || 0) - (a.level || 0));
    
    // Return top skill names
    return sortedSkills.slice(0, count).map(skill => skill.name);
  }

  /**
   * Get project types
   */
  private getProjectTypes(projects: any[]): string {
    if (!projects || projects.length === 0) {
      return 'various project types';
    }
    
    // Extract unique project types based on keywords in titles and descriptions
    const projectKeywords = new Set<string>();
    const keywordMap: Record<string, string> = {
      'develop': 'development projects',
      'implement': 'implementation initiatives',
      'design': 'design work',
      'architect': 'architecture design',
      'transform': 'transformation initiatives',
      'automate': 'automation solutions',
      'optimize': 'optimization efforts',
      'migrate': 'migration projects',
      'secure': 'security implementations',
      'integrate': 'integration work'
    };
    
    for (const project of projects) {
      const text = `${project.title} ${project.description}`.toLowerCase();
      
      for (const [keyword, projectType] of Object.entries(keywordMap)) {
        if (text.includes(keyword)) {
          projectKeywords.add(projectType);
        }
      }
    }
    
    // Return project types or default if none found
    return projectKeywords.size > 0 
      ? Array.from(projectKeywords).slice(0, 3).join(' to ')
      : 'various technical implementations';
  }

  /**
   * Get experience types
   */
  private getExperienceTypes(experiences: any[]): string {
    if (!experiences || experiences.length === 0) {
      return 'diverse professional contexts';
    }
    
    // Extract unique company industries or types
    const companyTypes = new Set<string>();
    
    for (const exp of experiences) {
      const company = exp.company.toLowerCase();
      
      if (company.includes('consult')) companyTypes.add('consulting environments');
      if (company.includes('tech') || company.includes('software')) companyTypes.add('technology companies');
      if (company.includes('finance') || company.includes('bank')) companyTypes.add('financial institutions');
      if (company.includes('health')) companyTypes.add('healthcare organizations');
      if (company.includes('retail')) companyTypes.add('retail businesses');
      if (company.includes('media')) companyTypes.add('media organizations');
      if (company.includes('education')) companyTypes.add('educational institutions');
      if (company.includes('government')) companyTypes.add('government agencies');
      if (company.includes('startup')) companyTypes.add('startups');
      if (company.includes('enterprise')) companyTypes.add('enterprise organizations');
    }
    
    // Return company types or default if none found
    return companyTypes.size > 0 
      ? Array.from(companyTypes).slice(0, 3).join(' and ')
      : 'various organizational contexts';
  }

  /**
   * Count words in narrative sections
   */
  private countWords(sections: any[]): number {
    let wordCount = 0;
    
    for (const section of sections) {
      if (section.content) {
        wordCount += section.content.split(/\s+/).length;
      }
    }
    
    return wordCount;
  }
}

export default new OutputService();
