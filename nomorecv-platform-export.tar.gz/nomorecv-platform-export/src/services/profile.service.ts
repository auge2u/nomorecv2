import { User, Profile, Experience, Education, Project, Skill, Trait } from '../interfaces/models';
import supabase from '../core/supabase';
import logger from '../utils/logger';
import { AppError } from '../middleware/error.middleware';

/**
 * Service for managing user profiles and related data
 */
export class ProfileService {
  /**
   * Get a user profile by ID
   */
  async getProfileById(profileId: string): Promise<Profile> {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', profileId)
        .single();

      if (error) {
        logger.error('Error fetching profile', { error, profileId });
        throw new AppError(`Profile not found: ${error.message}`, 404);
      }

      return data as Profile;
    } catch (error) {
      logger.error('Error in getProfileById', { error, profileId });
      throw error instanceof AppError ? error : new AppError('Failed to fetch profile', 500);
    }
  }

  /**
   * Get a profile by user ID
   */
  async getProfileByUserId(userId: string): Promise<Profile> {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('userId', userId)
        .single();

      if (error) {
        logger.error('Error fetching profile by userId', { error, userId });
        throw new AppError(`Profile not found: ${error.message}`, 404);
      }

      return data as Profile;
    } catch (error) {
      logger.error('Error in getProfileByUserId', { error, userId });
      throw error instanceof AppError ? error : new AppError('Failed to fetch profile', 500);
    }
  }

  /**
   * Create a new profile
   */
  async createProfile(profile: Omit<Profile, 'id' | 'createdAt' | 'updatedAt'>): Promise<Profile> {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .insert([{
          ...profile,
          createdAt: new Date(),
          updatedAt: new Date()
        }])
        .select()
        .single();

      if (error) {
        logger.error('Error creating profile', { error, profile });
        throw new AppError(`Failed to create profile: ${error.message}`, 400);
      }

      return data as Profile;
    } catch (error) {
      logger.error('Error in createProfile', { error, profile });
      throw error instanceof AppError ? error : new AppError('Failed to create profile', 500);
    }
  }

  /**
   * Update an existing profile
   */
  async updateProfile(profileId: string, updates: Partial<Profile>): Promise<Profile> {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .update({
          ...updates,
          updatedAt: new Date()
        })
        .eq('id', profileId)
        .select()
        .single();

      if (error) {
        logger.error('Error updating profile', { error, profileId, updates });
        throw new AppError(`Failed to update profile: ${error.message}`, 400);
      }

      return data as Profile;
    } catch (error) {
      logger.error('Error in updateProfile', { error, profileId, updates });
      throw error instanceof AppError ? error : new AppError('Failed to update profile', 500);
    }
  }

  /**
   * Get experiences for a profile
   */
  async getExperiences(profileId: string): Promise<Experience[]> {
    try {
      const { data, error } = await supabase
        .from('experiences')
        .select('*')
        .eq('profileId', profileId)
        .order('startDate', { ascending: false });

      if (error) {
        logger.error('Error fetching experiences', { error, profileId });
        throw new AppError(`Failed to fetch experiences: ${error.message}`, 400);
      }

      return data as Experience[];
    } catch (error) {
      logger.error('Error in getExperiences', { error, profileId });
      throw error instanceof AppError ? error : new AppError('Failed to fetch experiences', 500);
    }
  }

  /**
   * Get education entries for a profile
   */
  async getEducation(profileId: string): Promise<Education[]> {
    try {
      const { data, error } = await supabase
        .from('education')
        .select('*')
        .eq('profileId', profileId)
        .order('startDate', { ascending: false });

      if (error) {
        logger.error('Error fetching education', { error, profileId });
        throw new AppError(`Failed to fetch education: ${error.message}`, 400);
      }

      return data as Education[];
    } catch (error) {
      logger.error('Error in getEducation', { error, profileId });
      throw error instanceof AppError ? error : new AppError('Failed to fetch education', 500);
    }
  }

  /**
   * Get projects for a profile
   */
  async getProjects(profileId: string): Promise<Project[]> {
    try {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('profileId', profileId)
        .order('startDate', { ascending: false });

      if (error) {
        logger.error('Error fetching projects', { error, profileId });
        throw new AppError(`Failed to fetch projects: ${error.message}`, 400);
      }

      return data as Project[];
    } catch (error) {
      logger.error('Error in getProjects', { error, profileId });
      throw error instanceof AppError ? error : new AppError('Failed to fetch projects', 500);
    }
  }

  /**
   * Get skills for a profile
   */
  async getSkills(profileId: string): Promise<Skill[]> {
    try {
      const { data, error } = await supabase
        .from('skills')
        .select('*')
        .eq('profileId', profileId)
        .order('level', { ascending: false });

      if (error) {
        logger.error('Error fetching skills', { error, profileId });
        throw new AppError(`Failed to fetch skills: ${error.message}`, 400);
      }

      return data as Skill[];
    } catch (error) {
      logger.error('Error in getSkills', { error, profileId });
      throw error instanceof AppError ? error : new AppError('Failed to fetch skills', 500);
    }
  }

  /**
   * Get traits for a profile
   */
  async getTraits(profileId: string): Promise<Trait[]> {
    try {
      const { data, error } = await supabase
        .from('traits')
        .select('*')
        .eq('profileId', profileId)
        .order('score', { ascending: false });

      if (error) {
        logger.error('Error fetching traits', { error, profileId });
        throw new AppError(`Failed to fetch traits: ${error.message}`, 400);
      }

      return data as Trait[];
    } catch (error) {
      logger.error('Error in getTraits', { error, profileId });
      throw error instanceof AppError ? error : new AppError('Failed to fetch traits', 500);
    }
  }

  /**
   * Get complete profile data including all related entities
   */
  async getCompleteProfile(profileId: string): Promise<{
    profile: Profile;
    experiences: Experience[];
    education: Education[];
    projects: Project[];
    skills: Skill[];
    traits: Trait[];
  }> {
    try {
      const profile = await this.getProfileById(profileId);
      const [experiences, education, projects, skills, traits] = await Promise.all([
        this.getExperiences(profileId),
        this.getEducation(profileId),
        this.getProjects(profileId),
        this.getSkills(profileId),
        this.getTraits(profileId)
      ]);

      return {
        profile,
        experiences,
        education,
        projects,
        skills,
        traits
      };
    } catch (error) {
      logger.error('Error in getCompleteProfile', { error, profileId });
      throw error instanceof AppError ? error : new AppError('Failed to fetch complete profile', 500);
    }
  }
}

export default new ProfileService();
