import { handleProfilesApi } from './api/profiles';
import { handleTraitsApi } from './api/traits';
import { handleOutputsApi } from './api/outputs';
import { handleContentApi } from './api/content';
import { handleInterviewsApi } from './api/interviews';
import { handleBlockchainApi } from './api/blockchain';
import { Env } from './types';
import { createCorsResponse } from './utils/api';
import logger from './utils/logger';

export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    try {
      const url = new URL(request.url);
      const path = url.pathname.split('/').filter(Boolean);
      
      // Handle preflight requests
      if (request.method === 'OPTIONS') {
        return createCorsResponse({});
      }
      
      // API routes
      if (path[0] === 'api') {
        const apiPath = path.slice(1);
        
        if (apiPath[0] === 'profiles') {
          return handleProfilesApi(request, env, apiPath.slice(1));
        }
        
        if (apiPath[0] === 'traits') {
          return handleTraitsApi(request, env, apiPath.slice(1));
        }
        
        if (apiPath[0] === 'outputs') {
          return handleOutputsApi(request, env, apiPath.slice(1));
        }
        
        if (apiPath[0] === 'content') {
          return handleContentApi(request, env, apiPath.slice(1));
        }
        
        if (apiPath[0] === 'interviews') {
          return handleInterviewsApi(request, env, apiPath.slice(1));
        }
        
        if (apiPath[0] === 'blockchain') {
          return handleBlockchainApi(request, env, apiPath.slice(1));
        }
        
        // API endpoint not found
        return createCorsResponse({ error: 'API endpoint not found' }, 404);
      }
      
      // Default response for non-API routes
      return createCorsResponse({ error: 'Not found' }, 404);
    } catch (error) {
      logger.error('Unhandled error in worker', { error });
      return createCorsResponse({ error: 'Internal server error' }, 500);
    }
  }
};
