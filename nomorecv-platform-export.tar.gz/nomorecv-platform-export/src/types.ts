export interface Env {
  // Bindings for Cloudflare Workers
  NOMORECV_KV: KVNamespace;
  NOMORECV_STORAGE: R2Bucket;
  NOMORECV_DB: D1Database;
  INTERVIEW_SESSIONS: DurableObjectNamespace;
  STREAM: any; // Cloudflare Stream service
  EMAIL: any; // Cloudflare Email service
  
  // Environment variables
  ENVIRONMENT: string;
  SUPABASE_URL?: string;
  SUPABASE_KEY?: string;
  SUPABASE_SERVICE_ROLE_KEY?: string;
  BLOCKCHAIN_PROVIDER?: string;
  BLOCKCHAIN_NETWORK?: string;
  BLOCKCHAIN_RPC_URL?: string;
  BLOCKCHAIN_API_KEY?: string;
}
