import dotenv from 'dotenv';
import path from 'path';

// Load environment variables from .env file
dotenv.config();

const config = {
  // Server configuration
  server: {
    port: process.env.PORT || 3000,
    environment: process.env.NODE_ENV || 'development',
    apiPrefix: process.env.API_PREFIX || '/api/v1',
    corsOrigins: process.env.CORS_ORIGINS ? process.env.CORS_ORIGINS.split(',') : ['http://localhost:3000'],
  },
  
  // Supabase configuration
  supabase: {
    url: process.env.SUPABASE_URL || '',
    key: process.env.SUPABASE_KEY || '',
    serviceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY || '',
  },
  
  // Blockchain configuration
  blockchain: {
    provider: process.env.BLOCKCHAIN_PROVIDER || 'sui', // 'sui', 'solana', or 'cardano'
    network: process.env.BLOCKCHAIN_NETWORK || 'testnet',
    rpcUrl: process.env.BLOCKCHAIN_RPC_URL || '',
    apiKey: process.env.BLOCKCHAIN_API_KEY || '',
  },
  
  // Storage configuration
  storage: {
    bucket: process.env.STORAGE_BUCKET || 'nomorecv-platform',
    region: process.env.STORAGE_REGION || 'auto',
  },
  
  // Authentication configuration
  auth: {
    jwtSecret: process.env.JWT_SECRET || 'your-jwt-secret',
    jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
    refreshTokenExpiresIn: process.env.REFRESH_TOKEN_EXPIRES_IN || '30d',
  },
  
  // Logging configuration
  logging: {
    level: process.env.LOG_LEVEL || 'info',
    directory: process.env.LOG_DIRECTORY || path.join(process.cwd(), 'logs'),
  },
  
  // Email configuration
  email: {
    provider: process.env.EMAIL_PROVIDER || 'sendgrid',
    apiKey: process.env.EMAIL_API_KEY || '',
    fromEmail: process.env.EMAIL_FROM || 'noreply@nomorecv.com',
    fromName: process.env.EMAIL_FROM_NAME || 'NOMORECV Platform',
  },
  
  // Interview system configuration
  interview: {
    videoProvider: process.env.VIDEO_PROVIDER || 'cloudflare',
    apiKey: process.env.VIDEO_API_KEY || '',
    recordingBucket: process.env.RECORDING_BUCKET || 'interview-recordings',
  },
  
  // Content distribution configuration
  distribution: {
    defaultChannels: process.env.DEFAULT_CHANNELS ? process.env.DEFAULT_CHANNELS.split(',') : ['website'],
    maxScheduledItems: parseInt(process.env.MAX_SCHEDULED_ITEMS || '10', 10),
  },
};

export default config;
