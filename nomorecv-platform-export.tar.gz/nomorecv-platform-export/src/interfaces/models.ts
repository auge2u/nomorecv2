import { z } from 'zod';

/**
 * User interface representing a platform user
 */
export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  createdAt: Date;
  updatedAt: Date;
  isVerified: boolean;
  profileId?: string;
}

/**
 * Profile interface representing a user's professional profile
 */
export interface Profile {
  id: string;
  userId: string;
  headline: string;
  summary: string;
  location?: string;
  website?: string;
  avatarUrl?: string;
  isPublic: boolean;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Experience interface representing a professional experience entry
 */
export interface Experience {
  id: string;
  profileId: string;
  title: string;
  company: string;
  location?: string;
  startDate: Date;
  endDate?: Date;
  isCurrent: boolean;
  description: string;
  skills: string[];
  achievements: string[];
  verificationId?: string;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Education interface representing an education entry
 */
export interface Education {
  id: string;
  profileId: string;
  institution: string;
  degree: string;
  fieldOfStudy: string;
  startDate: Date;
  endDate?: Date;
  isCurrent: boolean;
  description?: string;
  verificationId?: string;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Project interface representing a project entry
 */
export interface Project {
  id: string;
  profileId: string;
  title: string;
  description: string;
  url?: string;
  startDate?: Date;
  endDate?: Date;
  isCurrent: boolean;
  skills: string[];
  outcomes: string[];
  mediaUrls: string[];
  verificationId?: string;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Skill interface representing a skill entry
 */
export interface Skill {
  id: string;
  profileId: string;
  name: string;
  category: string;
  level: number; // 1-5 scale
  endorsements: number;
  verificationId?: string;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Trait interface representing a persona trait
 */
export interface Trait {
  id: string;
  profileId: string;
  name: string;
  category: string;
  score: number; // 0-100 scale
  assessmentMethod: 'self' | 'external' | 'derived';
  assessmentDate: Date;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Verification interface representing a credential verification
 */
export interface Verification {
  id: string;
  entityId: string;
  entityType: 'experience' | 'education' | 'project' | 'skill';
  verifierType: 'blockchain' | 'third-party' | 'reference';
  verifierId?: string;
  status: 'pending' | 'verified' | 'rejected';
  proofType: 'zkp' | 'certificate' | 'reference';
  proofData: string;
  expiresAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Content interface representing distributable content
 */
export interface Content {
  id: string;
  profileId: string;
  title: string;
  description: string;
  contentType: 'article' | 'video' | 'image' | 'audio' | 'interactive';
  format: string;
  url?: string;
  data?: any;
  tags: string[];
  isPublic: boolean;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Distribution interface representing content distribution
 */
export interface Distribution {
  id: string;
  contentId: string;
  channelType: 'linkedin' | 'email' | 'website' | 'twitter' | 'custom';
  status: 'scheduled' | 'published' | 'failed';
  scheduledAt?: Date;
  publishedAt?: Date;
  audience?: any;
  metrics?: any;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Interview interface representing a career coach interview
 */
export interface Interview {
  id: string;
  profileId: string;
  title: string;
  description?: string;
  status: 'scheduled' | 'in-progress' | 'completed';
  scheduledAt?: Date;
  completedAt?: Date;
  videoUrl?: string;
  transcriptUrl?: string;
  insights?: any;
  contentIds: string[];
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Output interface representing a formatted output
 */
export interface Output {
  id: string;
  profileId: string;
  title: string;
  description?: string;
  outputType: 'cv' | 'portfolio' | 'pitch' | 'custom';
  format: 'web' | 'pdf' | 'interactive' | 'video';
  context?: string;
  industry?: string;
  url?: string;
  data?: any;
  createdAt: Date;
  updatedAt: Date;
}
