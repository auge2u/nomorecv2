import winston from 'winston';
import config from '../config';

// Define log format
const logFormat = winston.format.combine(
  winston.format.timestamp(),
  winston.format.json()
);

// Create logger instance
const logger = winston.createLogger({
  level: config.logging.level,
  format: logFormat,
  defaultMeta: { service: 'nomorecv-platform' },
  transports: [
    // Console transport for all environments
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      ),
    }),
    // File transport for non-development environments
    ...(config.server.environment !== 'development'
      ? [
          new winston.transports.File({
            filename: `${config.logging.directory}/error.log`,
            level: 'error',
          }),
          new winston.transports.File({
            filename: `${config.logging.directory}/combined.log`,
          }),
        ]
      : []),
  ],
});

export default logger;
