import { createClient } from '@supabase/supabase-js';
import { Env } from '../types';

// Create a Supabase client for use in Cloudflare Workers
export function getSupabaseClient(env: Env, useServiceRole = false) {
  const supabaseUrl = env.SUPABASE_URL;
  const supabaseKey = useServiceRole 
    ? env.SUPABASE_SERVICE_ROLE_KEY 
    : env.SUPABASE_KEY;
  
  if (!supabaseUrl || !supabaseKey) {
    throw new Error('Supabase URL and key must be provided in environment variables');
  }
  
  return createClient(supabaseUrl, supabaseKey);
}

// Helper function to extract user ID from JWT token
export async function getUserIdFromRequest(request: Request, env: Env): Promise<string | null> {
  // Get the authorization header
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  
  // Extract the token
  const token = authHeader.split(' ')[1];
  if (!token) {
    return null;
  }
  
  try {
    // Verify the token using Supabase
    const supabase = getSupabaseClient(env);
    const { data, error } = await supabase.auth.getUser(token);
    
    if (error || !data.user) {
      console.error('Error verifying token:', error);
      return null;
    }
    
    return data.user.id;
  } catch (error) {
    console.error('Error processing token:', error);
    return null;
  }
}

// Helper function to create a response with CORS headers
export function createCorsResponse(body: any, status = 200, headers = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      ...headers
    }
  });
}

// Helper function to handle errors
export function handleError(error: any) {
  console.error('Error:', error);
  
  const status = error.status || 500;
  const message = error.message || 'An unexpected error occurred';
  
  return createCorsResponse({ error: message }, status);
}

// Helper function to validate request body against a schema
export async function validateRequestBody(request: Request, schema: any) {
  try {
    const body = await request.json();
    return schema.parse(body);
  } catch (error) {
    throw { status: 400, message: 'Invalid request body' };
  }
}

// Helper function to check if user has access to a resource
export async function checkResourceAccess(env: Env, userId: string, resourceType: string, resourceId: string): Promise<boolean> {
  try {
    const supabase = getSupabaseClient(env, true);
    
    // Query the database to check if the user has access to the resource
    const { data, error } = await supabase
      .from(resourceType)
      .select('id')
      .eq('id', resourceId)
      .eq(resourceType === 'profiles' ? 'user_id' : 'profile_id', userId)
      .single();
    
    if (error || !data) {
      console.error('Error checking resource access:', error);
      return false;
    }
    
    return true;
  } catch (error) {
    console.error('Error checking resource access:', error);
    return false;
  }
}
