import { createClient } from '@supabase/supabase-js';
import config from '../config';

// Create Supabase client
const supabaseUrl = config.supabase.url;
const supabaseKey = config.supabase.key;

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Supabase URL and key must be provided in environment variables');
}

const supabase = createClient(supabaseUrl, supabaseKey);

export default supabase;
