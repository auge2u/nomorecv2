import { Request, Response, NextFunction } from 'express';
import logger from '../utils/logger';

interface ErrorResponse {
  status: string;
  message: string;
  stack?: string;
}

class AppError extends Error {
  statusCode: number;
  status: string;
  isOperational: boolean;

  constructor(message: string, statusCode: number) {
    super(message);
    this.statusCode = statusCode;
    this.status = `${statusCode}`.startsWith('4') ? 'fail' : 'error';
    this.isOperational = true;

    Error.captureStackTrace(this, this.constructor);
  }
}

const errorMiddleware = (
  err: AppError | Error,
  _req: Request,
  res: Response,
  _next: NextFunction
) => {
  const statusCode = 'statusCode' in err ? err.statusCode : 500;
  const status = 'status' in err ? err.status : 'error';

  const errorResponse: ErrorResponse = {
    status,
    message: err.message || 'Something went wrong',
  };

  // Add stack trace in development environment
  if (process.env.NODE_ENV === 'development') {
    errorResponse.stack = err.stack;
  }

  // Log error
  logger.error(`${statusCode} - ${err.message}`, {
    stack: err.stack,
    url: _req.originalUrl,
    method: _req.method,
  });

  res.status(statusCode).json(errorResponse);
};

export { AppError };
export default errorMiddleware;
