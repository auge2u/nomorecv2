// Main JavaScript for the responsive CV presentation tool

document.addEventListener('DOMContentLoaded', function() {
    // Initialize leadership radar chart
    initLeadershipRadarChart();
    
    // Initialize impact flow diagram
    initImpactFlowDiagram();
    
    // Add event listeners to industry cards
    document.querySelectorAll('.industry-card').forEach(card => {
        card.addEventListener('click', function() {
            const industry = this.dataset.industry;
            updatePerspective(industry);
        });
    });
    
    // Add event listener to perspective button
    document.getElementById('perspective-btn').addEventListener('click', function() {
        showPerspectiveModal();
    });
    
    // Add event listener to download button
    document.getElementById('download-btn').addEventListener('click', function() {
        prepareForDownload();
    });
});

// Initialize the leadership radar chart
function initLeadershipRadarChart() {
    const ctx = document.getElementById('leadership-radar-chart').getContext('2d');
    
    // Default data - will be updated based on selected industry
    const data = {
        labels: [
            'Strategic Vision',
            'Technical Expertise',
            'Innovation Leadership',
            'Team Development',
            'Business Acumen',
            'Change Management'
        ],
        datasets: [{
            label: 'Leadership Capabilities',
            data: [90, 85, 95, 80, 75, 85],
            fill: true,
            backgroundColor: 'rgba(79, 70, 229, 0.2)',
            borderColor: 'rgba(79, 70, 229, 1)',
            pointBackgroundColor: 'rgba(79, 70, 229, 1)',
            pointBorderColor: '#fff',
            pointHoverBackgroundColor: '#fff',
            pointHoverBorderColor: 'rgba(79, 70, 229, 1)'
        }]
    };
    
    const config = {
        type: 'radar',
        data: data,
        options: {
            elements: {
                line: {
                    borderWidth: 3
                }
            },
            scales: {
                r: {
                    angleLines: {
                        display: true
                    },
                    suggestedMin: 0,
                    suggestedMax: 100
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.raw + '% proficiency';
                        }
                    }
                }
            }
        }
    };
    
    window.leadershipChart = new Chart(ctx, config);
}

// Initialize the impact flow diagram using D3.js
function initImpactFlowDiagram() {
    const width = document.getElementById('impact-flow-diagram').clientWidth;
    const height = document.getElementById('impact-flow-diagram').clientHeight;
    
    const svg = d3.select('#impact-flow-diagram')
        .append('svg')
        .attr('width', width)
        .attr('height', height);
    
    // Default data - will be updated based on selected industry
    const nodes = [
        { id: 'strategy', label: 'Strategic Vision', x: width * 0.2, y: height * 0.3, r: 40, color: '#4F46E5' },
        { id: 'implementation', label: 'Implementation', x: width * 0.5, y: height * 0.2, r: 35, color: '#10B981' },
        { id: 'optimization', label: 'Optimization', x: width * 0.8, y: height * 0.3, r: 35, color: '#F59E0B' },
        { id: 'transformation', label: 'Transformation', x: width * 0.5, y: height * 0.7, r: 45, color: '#EC4899' }
    ];
    
    const links = [
        { source: 'strategy', target: 'implementation', value: 5 },
        { source: 'implementation', target: 'optimization', value: 3 },
        { source: 'strategy', target: 'transformation', value: 4 },
        { source: 'implementation', target: 'transformation', value: 3 },
        { source: 'optimization', target: 'transformation', value: 2 }
    ];
    
    // Create links
    svg.selectAll('.link')
        .data(links)
        .enter()
        .append('line')
        .attr('class', 'link')
        .attr('x1', function(d) {
            const source = nodes.find(node => node.id === d.source);
            return source.x;
        })
        .attr('y1', function(d) {
            const source = nodes.find(node => node.id === d.source);
            return source.y;
        })
        .attr('x2', function(d) {
            const target = nodes.find(node => node.id === d.target);
            return target.x;
        })
        .attr('y2', function(d) {
            const target = nodes.find(node => node.id === d.target);
            return target.y;
        })
        .attr('stroke-width', function(d) { return d.value * 2; })
        .attr('stroke', '#e5e7eb')
        .attr('opacity', 0.7);
    
    // Create nodes
    const nodeGroups = svg.selectAll('.node')
        .data(nodes)
        .enter()
        .append('g')
        .attr('class', 'node')
        .attr('transform', function(d) {
            return 'translate(' + d.x + ',' + d.y + ')';
        });
    
    nodeGroups.append('circle')
        .attr('r', function(d) { return d.r; })
        .attr('fill', function(d) { return d.color; })
        .attr('opacity', 0.8);
    
    nodeGroups.append('text')
        .attr('text-anchor', 'middle')
        .attr('dy', '.3em')
        .attr('fill', 'white')
        .attr('font-size', '12px')
        .attr('font-weight', 'bold')
        .text(function(d) { return d.label; });
    
    // Add animation
    nodeGroups.call(
        d3.drag()
            .on('start', dragstarted)
            .on('drag', dragged)
            .on('end', dragended)
    );
    
    function dragstarted(event, d) {
        d3.select(this).raise().attr('stroke', 'black');
    }
    
    function dragged(event, d) {
        d3.select(this).attr('transform', 'translate(' + (d.x = event.x) + ',' + (d.y = event.y) + ')');
        
        // Update connected links
        svg.selectAll('.link')
            .attr('x1', function(l) {
                const source = nodes.find(node => node.id === l.source);
                return source.x;
            })
            .attr('y1', function(l) {
                const source = nodes.find(node => node.id === l.source);
                return source.y;
            })
            .attr('x2', function(l) {
                const target = nodes.find(node => node.id === l.target);
                return target.x;
            })
            .attr('y2', function(l) {
                const target = nodes.find(node => node.id === l.target);
                return target.y;
            });
    }
    
    function dragended(event, d) {
        d3.select(this).attr('stroke', null);
    }
}

// Update the perspective based on selected industry
function updatePerspective(industry) {
    // Highlight selected industry card
    document.querySelectorAll('.industry-card').forEach(card => {
        if (card.dataset.industry === industry) {
            card.classList.add('ring-4', 'ring-indigo-500');
        } else {
            card.classList.remove('ring-4', 'ring-indigo-500');
        }
    });
    
    // Update leadership radar chart data based on industry
    updateLeadershipChart(industry);
    
    // Update capability breakdown
    updateCapabilityBreakdown(industry);
    
    // Update impact flow diagram
    updateImpactFlow(industry);
    
    // Update question responses
    updateQuestionResponses(industry);
    
    // Add fade-in animation to updated sections
    document.querySelectorAll('.bg-white').forEach(section => {
        section.classList.add('fade-in');
        setTimeout(() => {
            section.classList.remove('fade-in');
        }, 500);
    });
}

// Update leadership radar chart based on industry
function updateLeadershipChart(industry) {
    let data = [];
    
    switch(industry) {
        case 'financial-services':
            data = [95, 90, 85, 75, 80, 90];
            break;
        case 'tech-consulting':
            data = [85, 95, 90, 85, 80, 75];
            break;
        case 'ai-implementation':
            data = [80, 90, 95, 75, 70, 85];
            break;
        case 'digital-transformation':
            data = [90, 85, 90, 80, 85, 95];
            break;
        case 'startup-innovation':
            data = [85, 80, 95, 90, 85, 75];
            break;
        default:
            data = [90, 85, 95, 80, 75, 85];
    }
    
    window.leadershipChart.data.datasets[0].data = data;
    window.leadershipChart.update();
}

// Update capability breakdown based on industry
function updateCapabilityBreakdown(industry) {
    const capabilityData = {
        'financial-services': [
            { name: 'Regulatory Compliance', value: 95, color: 'blue', description: 'Implemented FINMA-approved infrastructure and compliance frameworks' },
            { name: 'Security Architecture', value: 90, color: 'purple', description: 'Designed secure, compliant cloud infrastructure for financial operations' },
            { name: 'Risk Management', value: 85, color: 'green', description: 'Developed comprehensive risk management frameworks for financial technology' },
            { name: 'Digital Banking', value: 80, color: 'red', description: 'Led digital transformation initiatives for banking operations' }
        ],
        'tech-consulting': [
            { name: 'Solution Architecture', value: 90, color: 'blue', description: 'Designed enterprise-scale technology solutions across multiple domains' },
            { name: 'Client Engagement', value: 85, color: 'purple', description: 'Maintained 95% client retention rate through strategic partnerships' },
            { name: 'Technical Leadership', value: 95, color: 'green', description: 'Led senior engineering and management initiatives' },
            { name: 'Strategic Consulting', value: 90, color: 'red', description: 'Provided C-level consulting focused on business process optimization' }
        ],
        'ai-implementation': [
            { name: 'LLM Integration', value: 95, color: 'blue', description: 'Developed enterprise-grade LLM integration platform with governance controls' },
            { name: 'AI Solution Design', value: 90, color: 'purple', description: 'Created AI-enhanced solutions for business operations' },
            { name: 'Prompt Engineering', value: 95, color: 'green', description: 'Developed sophisticated prompt management system with version control' },
            { name: 'AI Governance', value: 85, color: 'red', description: 'Implemented usage monitoring, cost optimization, and governance controls' }
        ],
        'digital-transformation': [
            { name: 'Change Management', value: 90, color: 'blue', description: 'Led organizational change initiatives for digital adoption' },
            { name: 'Process Optimization', value: 85, color: 'purple', description: 'Streamlined operations through enhanced processes' },
            { name: 'Technology Roadmapping', value: 95, color: 'green', description: 'Developed comprehensive roadmaps for infrastructure and applications' },
            { name: 'Digital Strategy', value: 90, color: 'red', description: 'Created strategic vision for digital business transformation' }
        ],
        'startup-innovation': [
            { name: 'Venture Building', value: 95, color: 'blue', description: 'Founded and scaled multiple successful startups' },
            { name: 'Product Development', value: 90, color: 'purple', description: 'Developed innovative platforms and applications' },
            { name: 'Team Leadership', value: 85, color: 'green', description: 'Built and led diverse teams across multiple disciplines' },
            { name: 'Market Strategy', value: 80, color: 'red', description: 'Developed go-to-market strategies for innovative products' }
        ],
        'custom': [
            { name: 'Strategic Vision', value: 90, color: 'blue', description: 'Developed comprehensive technology roadmaps aligned with business objectives' },
            { name: 'Technical Expertise', value: 85, color: 'purple', description: 'Deep expertise in cloud infrastructure, security, and AI integration' },
            { name: 'Innovation Leadership', value: 95, color: 'green', description: 'Led multiple innovation initiatives including AI integration' },
            { name: 'Team Development', value: 80, color: 'red', description: 'Built and led high-performing technical teams across multiple organizations' }
        ]
    };
    
    const data = capabilityData[industry] || capabilityData.custom;
    const container = document.getElementById('capability-breakdown');
    
    // Clear existing content
    container.innerHTML = '';
    
    // Add new capability cards
    data.forEach(capability => {
        const card = document.createElement('div');
        card.className = `bg-${capability.color}-50 p-4 rounded-lg`;
        
        card.innerHTML = `
            <h4 class="font-semibold text-${capability.color}-900 mb-2">${capability.name}</h4>
            <div class="relative pt-1">
                <div class="flex mb-2 items-center justify-between">
                    <div>
                        <span class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-${capability.color}-600 bg-${capability.color}-200">
                            Industry Relevance: ${capability.value}%
                        </span>
                    </div>
                </div>
                <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-${capability.color}-200">
                    <div style="width: ${capability.value}%" class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-${capability.color}-600"></div>
                </div>
                <p class="text-sm text-${capability.color}-800">${capability.description}</p>
            </div>
        `;
        
        container.appendChild(card);
    });
}

// Update impact flow diagram based on industry
function updateImpactFlow(industry) {
    // This would update the D3.js visualization based on industry
    // For simplicity, we'll just add a class to change colors
    const diagram = document.getElementById('impact-flow-diagram');
    
    // Remove all industry classes
    diagram.classList.remove(
        'financial-services-theme',
        'tech-consulting-theme',
        'ai-implementation-theme',
        'digital-transformation-theme',
        'startup-innovation-theme'
    );
    
    // Add selected industry class
    if (industry !== 'custom') {
        diagram.classList.add(`${industry}-theme`);
    }
}

// Update question responses based on industry
function updateQuestionResponses(industry) {
    const questionData = {
        'financial-services': [
            {
                question: 'How have you implemented security measures in financial technology systems?',
                response: 'At Sygnum Bank, I implemented Switzerland\'s first FINMA-approved IT infrastructure, establishing security controls that balanced regulatory compliance with operational efficiency. This included implementing zero-trust architecture, comprehensive threat detection, and automated compliance reporting aligned with financial regulations.'
            },
            {
                question: 'Describe your experience with regulatory compliance in financial services.',
                response: 'My experience includes designing and implementing regulatory-compliant infrastructure for crypto-finance operations at Sygnum Bank, where I worked directly with FINMA requirements. I\'ve developed compliance frameworks that automate monitoring and reporting while maintaining operational flexibility.'
            },
            {
                question: 'How do you balance innovation with security requirements in a regulated environment?',
                response: 'At Habitusnet, I developed an enterprise LLM gateway with governance controls that reduced AI implementation time by 70% while ensuring regulatory compliance. This approach allowed financial services clients to leverage cutting-edge AI capabilities within their strict security and compliance frameworks.'
            }
        ],
        'tech-consulting': [
            {
                question: 'Describe a challenging technology consulting project you\'ve led and its outcomes.',
                response: 'I led the implementation of a comprehensive security operations platform for a multi-cloud environment at a major financial institution. The project involved integrating real-time threat detection with AI-assisted triage across complex legacy and modern systems. By implementing a phased approach with continuous stakeholder engagement, we achieved a 40% reduction in alert triage time while significantly improving security posture.'
            },
            {
                question: 'How do you approach building client relationships and understanding their needs?',
                response: 'My approach to client relationships begins with deep listening to understand both stated and unstated needs. At Habitusnet Consulting, I maintained a 95% client retention rate over a decade by focusing on long-term partnerships rather than transactional engagements. This involved regular strategic reviews, proactive technology roadmapping, and ensuring that technical solutions directly addressed business objectives.'
            },
            {
                question: 'How do you stay current with emerging technologies?',
                response: 'I maintain a structured approach to technology currency that includes dedicated research time, participation in technical communities, hands-on experimentation with emerging technologies, and a network of specialists across various domains. This approach allowed me to successfully position clients for AI adoption well before it became mainstream, giving them competitive advantages in their industries.'
            }
        ],
        'ai-implementation': [
            {
                question: 'What experience do you have with LLM integration in enterprise environments?',
                response: 'I architected an enterprise-grade LLM integration platform for business process automation that included a sophisticated prompt management system with version control and performance analytics. The solution included custom connectors for Microsoft 365 and Dynamics 365, along with governance controls for responsible AI use. This reduced implementation time by 70% while ensuring regulatory compliance.'
            },
            {
                question: 'How do you approach ethical considerations in AI projects?',
                response: 'My approach to AI ethics is built on three pillars: governance, transparency, and continuous evaluation. For enterprise clients, I\'ve implemented frameworks that include bias detection, explainability mechanisms, usage monitoring, and regular ethical reviews. This structured approach has allowed organizations to leverage AI capabilities while maintaining alignment with their values and regulatory requirements.'
            },
            {
                question: 'How do you measure ROI for AI implementation projects?',
                response: 'I\'ve developed a multi-dimensional ROI framework for AI implementations that goes beyond cost reduction to include productivity gains, error reduction, employee satisfaction, and new capability enablement. For example, an intelligent document processing system I implemented achieved an 85% reduction in manual processing while improving accuracy, but also enabled entirely new service offerings that weren\'t possible before.'
            }
        ],
        'digital-transformation': [
            {
                question: 'What is your vision of what our company will look like after digital transformation?',
                response: 'My vision for digital transformation focuses on creating adaptive organizations that can continuously evolve with changing market conditions and technologies. This involves building modular technical architectures, developing digital capabilities in the workforce, implementing data-driven decision making, and creating a culture of continuous innovation. The end state isn\'t a fixed target but an organization with the capabilities to continuously transform itself.'
            },
            {
                question: 'Describe a significant digital transformation initiative you led and its outcomes.',
                response: 'At Sygnum Bank, I led a comprehensive transformation from reactive to proactive infrastructure management in a regulated crypto-finance environment. This involved implementing ITIL principles, rebuilding the IT operations team, and creating a roadmap integrating Microsoft 365, Teams, DevOps, and Infrastructure-as-Code. The result was a significant improvement in operational efficiency while maintaining strict regulatory compliance.'
            },
            {
                question: 'How do you address resistance to change during transformation initiatives?',
                response: 'I approach resistance to change by focusing on three elements: clear vision communication, stakeholder involvement, and demonstrable value creation. At Habitusnet, I implemented a change management framework that included regular stakeholder workshops, pilot programs with key influencers, and metrics-driven success demonstrations. This approach has consistently helped overcome initial resistance by building understanding and ownership of transformation initiatives.'
            }
        ],
        'startup-innovation': [
            {
                question: 'Describe a significant challenge you faced while building a startup and how you overcame it.',
                response: 'As CEO and co-founder of Flyerbee, I faced the challenge of building a marketplace platform that required both supply and demand sides to grow simultaneously. We addressed this through a phased approach, first focusing on high-value venues to create supply, then leveraging that exclusive inventory to attract advertisers. This strategy allowed us to grow to 15 employees and establish a viable marketplace before the pandemic disrupted our in-person business model.'
            },
            {
                question: 'How do you approach innovation in resource-constrained environments?',
                response: 'At Idezo, I led an innovation lab focused on emerging technologies with limited resources. Our approach was to create rapid prototyping capabilities, develop a network of specialized partners, and implement a rigorous prioritization framework for initiatives. This allowed us to develop groundbreaking concepts in AR/VR and computer vision while maintaining lean operations and focused resource allocation.'
            },
            {
                question: 'How do you build and motivate high-performing teams in startup environments?',
                response: 'My approach to building teams in startup environments focuses on finding versatile talent with growth mindsets, creating clear alignment around mission and objectives, implementing lightweight but effective processes, and fostering a culture of ownership and accountability. At Flyerbee, this approach enabled us to build a team that could adapt quickly to market feedback and evolving business requirements.'
            }
        ],
        'custom': [
            {
                question: 'How have you leveraged AI and LLMs to build transformative strategies?',
                response: 'I\'ve pioneered the integration of LLMs into enterprise environments, developing frameworks that allow organizations to leverage AI capabilities while maintaining governance and compliance. For example, I created an enterprise LLM gateway with sophisticated prompt management that reduced AI implementation time by 70% while ensuring regulatory compliance. This approach has enabled organizations to transform their operations by automating complex processes, enhancing decision-making, and creating entirely new capabilities.'
            },
            {
                question: 'How do you balance technical expertise with business leadership?',
                response: 'My approach combines deep technical knowledge with strategic business thinking. At Habitusnet, I provided C-level consulting focused on aligning technology initiatives with business objectives, ensuring that technical solutions directly addressed organizational challenges. This balanced perspective has allowed me to bridge the gap between technical possibilities and business realities, creating technology strategies that deliver measurable value.'
            },
            {
                question: 'What is your approach to leading through technological paradigm shifts?',
                response: 'I focus on creating adaptive organizations that can continuously evolve with changing technologies. This involves building modular technical architectures, developing digital capabilities in the workforce, implementing data-driven decision making, and fostering a culture of continuous learning. For example, at Sygnum Bank, I led a comprehensive transformation that prepared the organization for ongoing evolution in the rapidly changing crypto-finance landscape.'
            }
        ]
    };
    
    const data = questionData[industry] || questionData.custom;
    const container = document.getElementById('question-responses');
    
    // Clear existing content
    container.innerHTML = '';
    
    // Add new question responses
    data.forEach(item => {
        const card = document.createElement('div');
        card.className = 'bg-gray-50 p-4 rounded-lg';
        
        card.innerHTML = `
            <h3 class="text-xl font-semibold text-gray-800 mb-2">${item.question}</h3>
            <div class="pl-4 border-l-4 border-indigo-500">
                <p class="text-gray-700">${item.response}</p>
            </div>
        `;
        
        container.appendChild(card);
    });
}

// Show perspective selection modal
function showPerspectiveModal() {
    // This would show a modal with more detailed perspective options
    // For simplicity, we'll just cycle through industries
    const industries = ['financial-services', 'tech-consulting', 'ai-implementation', 'digital-transformation', 'startup-innovation', 'custom'];
    
    // Find currently selected industry
    let currentIndustry = '';
    document.querySelectorAll('.industry-card').forEach(card => {
        if (card.classList.contains('ring-4')) {
            currentIndustry = card.dataset.industry;
        }
    });
    
    // Get next industry in cycle
    const currentIndex = industries.indexOf(currentIndustry);
    const nextIndex = (currentIndex + 1) % industries.length;
    const nextIndustry = industries[nextIndex];
    
    // Update perspective
    updatePerspective(nextIndustry);
}

// Prepare for download/print
function prepareForDownload() {
    // This would prepare the page for printing or PDF generation
    window.print();
}
