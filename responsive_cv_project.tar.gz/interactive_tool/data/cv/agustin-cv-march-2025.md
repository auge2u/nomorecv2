# AGUSTIN MUSI
**+41 794403287 | agustin@musi.ch | [linkedin.com/in/agustinmusi](https://linkedin.com/in/agustinmusi/)**

## PROFESSIONAL SUMMARY
Senior technology leader with over 25 years of experience spanning infrastructure management, security implementation, business operations, and organizational leadership. Demonstrated expertise in enhancing operational efficiency through strategic consulting, business process optimization, and innovative technology solutions. Proven track record of building and leading high-performing teams in multi-cloud environments while providing C-level strategic consulting to optimize internal processes. Committed to driving organizational growth by developing effective strategies to attract and retain top talent while delivering exceptional technical solutions.

## CORE COMPETENCIES
- **Enterprise Technology:** Microsoft 365 security implementations, MS Dynamics 365 solutions, multi-cloud environment management (Azure, AWS, M365, D365)
- **Infrastructure & Security:** IT infrastructure design, ITIL implementation, cybersecurity practices, Infrastructure-as-Code (IaC)
- **AI & Automation:** LLM integration, AI solution development, automation frameworks, intelligent workflow systems
- **Leadership:** Strategic planning, team building, C-level consulting, talent acquisition, performance management
- **Business Operations:** Process optimization, compliance management, strategic roadmapping, partnership development

## PROFESSIONAL EXPERIENCE

### HABITUSNET CONSULTING AG
**Head of Infrastructure & Security Consulting** | Zürich, Switzerland | Apr 2022 - Present

Led comprehensive infrastructure, security, and AI integration initiatives while providing strategic consulting to enterprise clients. Developed innovative solutions leveraging Microsoft 365, Dynamics 365, and custom AI implementations.

**Key Enterprise Projects:**

#### Enterprise Shift Management System
- Architected and implemented a comprehensive workforce management solution using Microsoft Power Platform
- Integrated custom modules for scheduling, compliance tracking, and performance analytics
- Deployed to multiple enterprise clients with 500+ employees, resulting in 40% reduction in scheduling conflicts
- Implemented automated reporting and analytics dashboard for management oversight

#### Cloud Infrastructure Automation Platform
- Developed a comprehensive Infrastructure-as-Code (IaC) framework integrating with Microsoft Azure
- Created templated deployment patterns for rapid provisioning of secure, compliant environments
- Implemented automated compliance scanning and remediation capabilities
- Reduced client infrastructure deployment time by 65% while maintaining security best practices

#### LLM Integration Framework & Prompt Engineering System
- Designed and implemented an enterprise-grade LLM integration platform for business process automation
- Created a sophisticated prompt management system with version control and performance analytics
- Developed custom connectors for integration with Microsoft 365 and Dynamics 365
- Implemented usage monitoring, cost optimization, and governance controls

#### Advanced Security Operations Console
- Architected a comprehensive security operations platform for multi-cloud environments
- Implemented real-time threat detection and response capabilities with AI-assisted triage
- Developed customized compliance reporting aligned with FINMA, GDPR, and industry standards
- Created executive-level dashboards for security posture visualization and risk management

#### Microsoft 365 Enterprise Migration Toolkit
- Developed a comprehensive migration framework for complex enterprise environments
- Created automated assessment, planning, and execution tools for large-scale migrations
- Implemented specialized security hardening and compliance controls
- Reduced typical migration timeframes by 30% while improving security posture

**Additional Responsibilities:**
- Led senior engineering, management, and migration initiatives within the Microsoft 365 ecosystem to enhance scalability and efficiency
- Developed customized MS Dynamics 365 solutions for CRM/Sales, Business Central, and Project Management
- Integrated automation utilizing Infrastructure-as-Code (IaC) principles to streamline processes
- Provided C-level strategic consulting focused on business process optimization and infrastructure planning
- Managed recruitment, talent acquisition, and team building for cutting-edge tech initiatives, refining strategies to attract top talent
- Created multiple platforms and applications for clients, leveraging in-house and external Machine Learning (LLMs) to enhance client interaction with IT and automation
- Directed strategic leadership in operations roadmaps to advance AI and SaaS development projects

### SYGNUM BANK AG
**Head of Infrastructure** | Zürich, Switzerland | Mar 2021 - Mar 2022

- Rebuilt a strong IT operations team in a regulated crypto-finance environment following the departure of the previous support team lead
- Implemented Switzerland's first FINMA-approved IT infrastructure
- Adopted ITIL principles, transitioning infrastructure management from reactive to proactive, and boosting operational efficiency
- Architect for a comprehensive roadmap for infrastructure, integrating Microsoft 365, Teams, DevOps, and IAC
- Managed technical engineering, project management, and vendor relationships within a multi-cloud environment (Azure, AWS, Dynamics 365)
- Recruited and led teams in key sectors, including Dynamics 365 Development and ITSM
- Led technical support for a range of projects (Atlassian, Azure infrastructure, Blockchain production products)
- Implemented performance management processes to enhance goal setting, mid-year reviews, and annual performance reviews, improving organizational effectiveness

### FLYERBEE AG
**CEO / co-founder** | Zürich, Switzerland | Mar 2016 - Feb 2021

- Founded, drove, and funded a successful startup (until Covid) with 15 employees in developing a hyper-local, "anti-globalized Ad/Logistics marketplace" leveraging a distributed ground force for in-person venue contract development
- Developed a Mobile Workforce Platform featuring ad space reservation, planning, and lifecycle management integrated with BLE sensors and mobile data analytics, prioritizing privacy and audience engagement
- Collaborated with investors, customers, and teams to formulate strategic plans to achieve platform business objectives
- Recruited and managed a diverse team of over 30 developers and professionals, fostering collaboration and innovation
- Conducted client research and testing initiatives for the mobile app, campaign management, and marketplace platform to enhance user experience
- Led product management efforts focusing on location-based and ad tech industry trends, driving innovation in products and services
- Implemented pilot projects and proof of concepts (POCs) with clients to promote platform adoption across small and large European businesses, effectively pitching to stakeholders
- Oversaw compliance, legal issues, and shareholder relationships to ensure organizational integrity and governance
- Demonstrated diverse leadership abilities across various roles, including Head of HR, Head of Legal, Head of Compliance, Head of Marketing, Head of Engineering, Head of Product, Head of Sales, and Head of Janitorial Services

### HABITUSNET CONSULTING AG
**Managing Partner** | Zürich, Switzerland | 2000 - 2016

- Founded Habitusnet Consulting, repositioning the company to focus on IT and office design services based on market trends
- Built a consulting team that supports 25+ organizations across Europe, including clients in the UK, Netherlands, and Switzerland, specializing in IT operations and office technology infrastructure
- Achieved 100% growth with new clients, bottom-line revenue from 2007 to 2011, and a 40% increase in hosting revenue, culminating in a successful spin-off
- Maintained a 95% client retention rate over a decade
- Spearheaded cloud transformation initiatives, providing innovative IT solutions for business operations and digital transformation consulting
- Led and developed a large team of senior technology consultants (internal and external), promoting a collaborative and growth-focused work environment

### IDEZO GMBH
**co-founder, Director** | Zürich, Switzerland | 2014 - 2020

- Founded and directed an innovation lab focused on emerging technologies, including AR/VR, computer vision, adaptive tech, and HMI
- Developed groundbreaking concepts by integrating design and engineering for impactful client solutions
- Built and nurtured a cross-functional team, fostering a culture of creativity and results-driven collaboration
- Optimized lab operations through effective budget allocation and technology infrastructure management
- Emphasized storytelling in client engagement, ensuring effective translation of the lab's vision and solutions

### NHABITUS GMBH
**Director, Founder** | Zürich, Switzerland | 2009 - 2020

- Spearheaded technical development, optimizing platform performance for reliability, security, billing, and customer satisfaction
- Drove strategic partnerships for rapid business expansion
- Streamlined operations through enhanced processes, achieving cost reduction and improved quality
- Established and led a high-performing team, dedicated to exceeding collective goals

### UBS AG / SBC WARBURG / PEROT SYSTEMS
**Windows Systems Platform Engineering, Organizational Consulting, and Software Project Manager** | 1996-1999

### AUTODESK INC.
**IT Services Manager** | Seattle, WA, Portland, OR | 1994-1996

## EDUCATION
**University of Washington**, Seattle, WA | 1990-1995  
Physics, Business, IT

## CERTIFICATIONS
- Six Sigma Foundations: Process improvement methodology
- Microsoft 365 Governance & Compliance: Ensuring data security and regulatory adherence
- ITIL Foundation: IT service management
- Azure Architecture, Cybersecurity: Net, Hardware, IAM, Leadership Development

## TECHNICAL SKILLS
- **Microsoft Ecosystem:** Microsoft 365 security, MS Dynamics 365, Power Platform, PowerApps, SharePoint
- **Cloud & Infrastructure:** Azure, AWS, Infrastructure-as-Code, cloud computing, ITIL implementation
- **Containerization:** Kubernetes, Docker, container orchestration
- **Development & Automation:** Python, JavaScript/TypeScript, Electron, automation frameworks
- **AI & Data:** LLM integration, AI solution development, data analytics, prompt engineering
- **Security:** Cybersecurity best practices, compliance frameworks, security operations
- **Mobile & Endpoint:** iOS integration, hybrid infrastructure, endpoint management

## BUSINESS SKILLS
- Strategic consulting and leadership
- Business process optimization
- Recruitment and talent management
- Product management and innovation
- Financial acumen and budgeting
- Compliance and legal management
- Marketing and go-to-market strategy
- Client relationship management
