from flask import Flask, render_template, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import json
import yaml
import markdown
import re

app = Flask(__name__, static_folder='static')
CORS(app)

# Data directories
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
CV_DIR = os.path.join(DATA_DIR, 'cv')
INDUSTRY_DIR = os.path.join(DATA_DIR, 'industries')
EXPERIENCE_DIR = os.path.join(DATA_DIR, 'experiences')

# Ensure directories exist
os.makedirs(CV_DIR, exist_ok=True)
os.makedirs(INDUSTRY_DIR, exist_ok=True)
os.makedirs(EXPERIENCE_DIR, exist_ok=True)

def load_yaml_data(file_path):
    """Load YAML data from file"""
    try:
        with open(file_path, 'r') as file:
            return yaml.safe_load(file)
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return {}

def load_markdown_data(file_path):
    """Load Markdown data from file and convert to HTML"""
    try:
        with open(file_path, 'r') as file:
            content = file.read()
            return markdown.markdown(content)
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return ""

def get_industries():
    """Get list of available industries"""
    industries = []
    try:
        for filename in os.listdir(INDUSTRY_DIR):
            if filename.endswith('.yaml'):
                industry_id = filename.replace('.yaml', '')
                industry_data = load_yaml_data(os.path.join(INDUSTRY_DIR, filename))
                industries.append({
                    'id': industry_id,
                    'name': industry_data.get('name', industry_id),
                    'description': industry_data.get('description', '')
                })
    except Exception as e:
        print(f"Error getting industries: {e}")
    return industries

def get_experiences():
    """Get list of available experiences"""
    experiences = []
    try:
        for filename in os.listdir(EXPERIENCE_DIR):
            if filename.endswith('.yaml'):
                exp_id = filename.replace('.yaml', '')
                exp_data = load_yaml_data(os.path.join(EXPERIENCE_DIR, filename))
                experiences.append({
                    'id': exp_id,
                    'title': exp_data.get('title', exp_id),
                    'company': exp_data.get('company', ''),
                    'period': exp_data.get('period', ''),
                    'tags': exp_data.get('tags', [])
                })
    except Exception as e:
        print(f"Error getting experiences: {e}")
    return experiences

def get_cv_versions():
    """Get list of available CV versions"""
    versions = []
    try:
        for filename in os.listdir(CV_DIR):
            if filename.endswith('.md'):
                version_id = filename.replace('.md', '')
                versions.append({
                    'id': version_id,
                    'name': version_id.replace('-', ' ').title()
                })
    except Exception as e:
        print(f"Error getting CV versions: {e}")
    return versions

def generate_industry_response(industry_id):
    """Generate tailored response for specific industry"""
    industry_file = os.path.join(INDUSTRY_DIR, f"{industry_id}.yaml")
    if not os.path.exists(industry_file):
        return {"error": "Industry not found"}
    
    industry_data = load_yaml_data(industry_file)
    experiences = get_experiences()
    
    # Filter and rank experiences based on industry relevance
    relevant_experiences = []
    for exp in experiences:
        exp_file = os.path.join(EXPERIENCE_DIR, f"{exp['id']}.yaml")
        if os.path.exists(exp_file):
            exp_data = load_yaml_data(exp_file)
            relevance_score = 0
            
            # Calculate relevance based on matching tags
            industry_tags = industry_data.get('relevant_tags', [])
            exp_tags = exp_data.get('tags', [])
            matching_tags = set(industry_tags).intersection(set(exp_tags))
            relevance_score = len(matching_tags)
            
            if relevance_score > 0:
                exp_data['relevance_score'] = relevance_score
                relevant_experiences.append(exp_data)
    
    # Sort by relevance score
    relevant_experiences.sort(key=lambda x: x.get('relevance_score', 0), reverse=True)
    
    # Generate responses to common questions
    common_questions = industry_data.get('common_questions', [])
    question_responses = []
    
    for question in common_questions:
        q_text = question.get('question', '')
        response_template = question.get('response_template', '')
        
        # Replace placeholders with actual experience data
        if relevant_experiences and response_template:
            top_exp = relevant_experiences[0]
            response = response_template.replace('{company}', top_exp.get('company', ''))
            response = response.replace('{project}', top_exp.get('project', ''))
            response = response.replace('{outcome}', top_exp.get('outcome', ''))
        else:
            response = "No specific experience data available for this question."
        
        question_responses.append({
            'question': q_text,
            'response': response
        })
    
    return {
        'industry': industry_data,
        'relevant_experiences': relevant_experiences[:5],  # Top 5 most relevant
        'question_responses': question_responses
    }

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/api/industries')
def api_industries():
    return jsonify(get_industries())

@app.route('/api/experiences')
def api_experiences():
    return jsonify(get_experiences())

@app.route('/api/cv-versions')
def api_cv_versions():
    return jsonify(get_cv_versions())

@app.route('/api/industry/<industry_id>')
def api_industry(industry_id):
    return jsonify(generate_industry_response(industry_id))

@app.route('/api/cv/<version_id>')
def api_cv(version_id):
    cv_file = os.path.join(CV_DIR, f"{version_id}.md")
    if not os.path.exists(cv_file):
        return jsonify({"error": "CV version not found"})
    
    cv_content = load_markdown_data(cv_file)
    return jsonify({
        'id': version_id,
        'name': version_id.replace('-', ' ').title(),
        'content': cv_content
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
